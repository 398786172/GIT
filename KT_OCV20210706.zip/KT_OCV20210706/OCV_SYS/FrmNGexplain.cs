﻿using System.Windows.Forms;

namespace OCV
{
    public partial class ForNGexplain : Form
    {
        public ForNGexplain()
        {
            InitializeComponent();
        }

    }
}
