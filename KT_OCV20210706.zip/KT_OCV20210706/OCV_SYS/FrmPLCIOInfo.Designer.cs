﻿namespace TrayLogin
{
    partial class FrmPLCIOInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPLCIOInfo));
            this.tabControl1 = new DevComponents.DotNetBar.TabControl();
            this.tabControlPanel1 = new DevComponents.DotNetBar.TabControlPanel();
            this.uLan_x42 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x43 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x45 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x46 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x44 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x41 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x40 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x47 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x52 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x53 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x55 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x56 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x54 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x51 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x50 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x57 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x72 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x73 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x75 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x76 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x74 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x71 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x70 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x77 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x62 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x63 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x65 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x66 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x64 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x61 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x60 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x67 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x32 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x33 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x35 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x36 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x34 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x31 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x30 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x37 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x22 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x23 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x25 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x26 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x24 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x21 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x20 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x27 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x12 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x13 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x15 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x16 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x14 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x11 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x10 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x17 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x2 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x3 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x5 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x6 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x4 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x1 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x0 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_x7 = new ClsDeviceComm.Controls.UserLantern();
            this.lbl_x77 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x76 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x75 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x74 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x73 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x72 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x71 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x70 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x67 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x66 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x65 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x64 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x63 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x62 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x61 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x60 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x57 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x56 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x55 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x54 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x53 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x52 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x51 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x50 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x47 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x46 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x45 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x44 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x43 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x42 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x41 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x40 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x37 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x36 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x35 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x34 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x33 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x32 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x31 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x27 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x25 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x30 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x26 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x24 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x23 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x22 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x21 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x20 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x17 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x16 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x15 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x14 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x13 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x12 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x7 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x6 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x5 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x4 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x3 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x2 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x1 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x11 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x10 = new DevComponents.DotNetBar.LabelX();
            this.lbl_x0 = new DevComponents.DotNetBar.LabelX();
            this.tabItem1 = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel2 = new DevComponents.DotNetBar.TabControlPanel();
            this.uLan_y46 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y42 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y43 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y45 = new ClsDeviceComm.Controls.UserLantern();
            this.userLantern100 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y44 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y41 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y40 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y47 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y2 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y3 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y5 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y6 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y4 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y1 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y0 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y7 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y32 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y33 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y35 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y36 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y34 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y31 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y30 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y37 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y22 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y23 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y25 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y26 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y24 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y21 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y20 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y27 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y12 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y13 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y15 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y16 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y14 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y11 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y10 = new ClsDeviceComm.Controls.UserLantern();
            this.uLan_y17 = new ClsDeviceComm.Controls.UserLantern();
            this.lbl_y47 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y46 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y45 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y44 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y43 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y42 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y41 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y40 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y37 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y36 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y35 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y34 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y33 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y32 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y31 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y27 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y25 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y30 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y26 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y24 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y23 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y22 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y21 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y20 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y17 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y16 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y15 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y14 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y13 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y12 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y7 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y6 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y5 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y4 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y3 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y2 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y1 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y11 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y10 = new DevComponents.DotNetBar.LabelX();
            this.lbl_y0 = new DevComponents.DotNetBar.LabelX();
            this.tabItem2 = new DevComponents.DotNetBar.TabItem(this.components);
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.tabControl1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabControlPanel1.SuspendLayout();
            this.tabControlPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.CanReorderTabs = true;
            this.tabControl1.Controls.Add(this.tabControlPanel1);
            this.tabControl1.Controls.Add(this.tabControlPanel2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedTabFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold);
            this.tabControl1.SelectedTabIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(817, 645);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.TabLayoutType = DevComponents.DotNetBar.eTabLayoutType.FixedWithNavigationBox;
            this.tabControl1.Tabs.Add(this.tabItem1);
            this.tabControl1.Tabs.Add(this.tabItem2);
            this.tabControl1.Text = "tabControl1";
            // 
            // tabControlPanel1
            // 
            this.tabControlPanel1.Controls.Add(this.uLan_x42);
            this.tabControlPanel1.Controls.Add(this.uLan_x43);
            this.tabControlPanel1.Controls.Add(this.uLan_x45);
            this.tabControlPanel1.Controls.Add(this.uLan_x46);
            this.tabControlPanel1.Controls.Add(this.uLan_x44);
            this.tabControlPanel1.Controls.Add(this.uLan_x41);
            this.tabControlPanel1.Controls.Add(this.uLan_x40);
            this.tabControlPanel1.Controls.Add(this.uLan_x47);
            this.tabControlPanel1.Controls.Add(this.uLan_x52);
            this.tabControlPanel1.Controls.Add(this.uLan_x53);
            this.tabControlPanel1.Controls.Add(this.uLan_x55);
            this.tabControlPanel1.Controls.Add(this.uLan_x56);
            this.tabControlPanel1.Controls.Add(this.uLan_x54);
            this.tabControlPanel1.Controls.Add(this.uLan_x51);
            this.tabControlPanel1.Controls.Add(this.uLan_x50);
            this.tabControlPanel1.Controls.Add(this.uLan_x57);
            this.tabControlPanel1.Controls.Add(this.uLan_x72);
            this.tabControlPanel1.Controls.Add(this.uLan_x73);
            this.tabControlPanel1.Controls.Add(this.uLan_x75);
            this.tabControlPanel1.Controls.Add(this.uLan_x76);
            this.tabControlPanel1.Controls.Add(this.uLan_x74);
            this.tabControlPanel1.Controls.Add(this.uLan_x71);
            this.tabControlPanel1.Controls.Add(this.uLan_x70);
            this.tabControlPanel1.Controls.Add(this.uLan_x77);
            this.tabControlPanel1.Controls.Add(this.uLan_x62);
            this.tabControlPanel1.Controls.Add(this.uLan_x63);
            this.tabControlPanel1.Controls.Add(this.uLan_x65);
            this.tabControlPanel1.Controls.Add(this.uLan_x66);
            this.tabControlPanel1.Controls.Add(this.uLan_x64);
            this.tabControlPanel1.Controls.Add(this.uLan_x61);
            this.tabControlPanel1.Controls.Add(this.uLan_x60);
            this.tabControlPanel1.Controls.Add(this.uLan_x67);
            this.tabControlPanel1.Controls.Add(this.uLan_x32);
            this.tabControlPanel1.Controls.Add(this.uLan_x33);
            this.tabControlPanel1.Controls.Add(this.uLan_x35);
            this.tabControlPanel1.Controls.Add(this.uLan_x36);
            this.tabControlPanel1.Controls.Add(this.uLan_x34);
            this.tabControlPanel1.Controls.Add(this.uLan_x31);
            this.tabControlPanel1.Controls.Add(this.uLan_x30);
            this.tabControlPanel1.Controls.Add(this.uLan_x37);
            this.tabControlPanel1.Controls.Add(this.uLan_x22);
            this.tabControlPanel1.Controls.Add(this.uLan_x23);
            this.tabControlPanel1.Controls.Add(this.uLan_x25);
            this.tabControlPanel1.Controls.Add(this.uLan_x26);
            this.tabControlPanel1.Controls.Add(this.uLan_x24);
            this.tabControlPanel1.Controls.Add(this.uLan_x21);
            this.tabControlPanel1.Controls.Add(this.uLan_x20);
            this.tabControlPanel1.Controls.Add(this.uLan_x27);
            this.tabControlPanel1.Controls.Add(this.uLan_x12);
            this.tabControlPanel1.Controls.Add(this.uLan_x13);
            this.tabControlPanel1.Controls.Add(this.uLan_x15);
            this.tabControlPanel1.Controls.Add(this.uLan_x16);
            this.tabControlPanel1.Controls.Add(this.uLan_x14);
            this.tabControlPanel1.Controls.Add(this.uLan_x11);
            this.tabControlPanel1.Controls.Add(this.uLan_x10);
            this.tabControlPanel1.Controls.Add(this.uLan_x17);
            this.tabControlPanel1.Controls.Add(this.uLan_x2);
            this.tabControlPanel1.Controls.Add(this.uLan_x3);
            this.tabControlPanel1.Controls.Add(this.uLan_x5);
            this.tabControlPanel1.Controls.Add(this.uLan_x6);
            this.tabControlPanel1.Controls.Add(this.uLan_x4);
            this.tabControlPanel1.Controls.Add(this.uLan_x1);
            this.tabControlPanel1.Controls.Add(this.uLan_x0);
            this.tabControlPanel1.Controls.Add(this.uLan_x7);
            this.tabControlPanel1.Controls.Add(this.lbl_x77);
            this.tabControlPanel1.Controls.Add(this.lbl_x76);
            this.tabControlPanel1.Controls.Add(this.lbl_x75);
            this.tabControlPanel1.Controls.Add(this.lbl_x74);
            this.tabControlPanel1.Controls.Add(this.lbl_x73);
            this.tabControlPanel1.Controls.Add(this.lbl_x72);
            this.tabControlPanel1.Controls.Add(this.lbl_x71);
            this.tabControlPanel1.Controls.Add(this.lbl_x70);
            this.tabControlPanel1.Controls.Add(this.lbl_x67);
            this.tabControlPanel1.Controls.Add(this.lbl_x66);
            this.tabControlPanel1.Controls.Add(this.lbl_x65);
            this.tabControlPanel1.Controls.Add(this.lbl_x64);
            this.tabControlPanel1.Controls.Add(this.lbl_x63);
            this.tabControlPanel1.Controls.Add(this.lbl_x62);
            this.tabControlPanel1.Controls.Add(this.lbl_x61);
            this.tabControlPanel1.Controls.Add(this.lbl_x60);
            this.tabControlPanel1.Controls.Add(this.lbl_x57);
            this.tabControlPanel1.Controls.Add(this.lbl_x56);
            this.tabControlPanel1.Controls.Add(this.lbl_x55);
            this.tabControlPanel1.Controls.Add(this.lbl_x54);
            this.tabControlPanel1.Controls.Add(this.lbl_x53);
            this.tabControlPanel1.Controls.Add(this.lbl_x52);
            this.tabControlPanel1.Controls.Add(this.lbl_x51);
            this.tabControlPanel1.Controls.Add(this.lbl_x50);
            this.tabControlPanel1.Controls.Add(this.lbl_x47);
            this.tabControlPanel1.Controls.Add(this.lbl_x46);
            this.tabControlPanel1.Controls.Add(this.lbl_x45);
            this.tabControlPanel1.Controls.Add(this.lbl_x44);
            this.tabControlPanel1.Controls.Add(this.lbl_x43);
            this.tabControlPanel1.Controls.Add(this.lbl_x42);
            this.tabControlPanel1.Controls.Add(this.lbl_x41);
            this.tabControlPanel1.Controls.Add(this.lbl_x40);
            this.tabControlPanel1.Controls.Add(this.lbl_x37);
            this.tabControlPanel1.Controls.Add(this.lbl_x36);
            this.tabControlPanel1.Controls.Add(this.lbl_x35);
            this.tabControlPanel1.Controls.Add(this.lbl_x34);
            this.tabControlPanel1.Controls.Add(this.lbl_x33);
            this.tabControlPanel1.Controls.Add(this.lbl_x32);
            this.tabControlPanel1.Controls.Add(this.lbl_x31);
            this.tabControlPanel1.Controls.Add(this.lbl_x27);
            this.tabControlPanel1.Controls.Add(this.lbl_x25);
            this.tabControlPanel1.Controls.Add(this.lbl_x30);
            this.tabControlPanel1.Controls.Add(this.lbl_x26);
            this.tabControlPanel1.Controls.Add(this.lbl_x24);
            this.tabControlPanel1.Controls.Add(this.lbl_x23);
            this.tabControlPanel1.Controls.Add(this.lbl_x22);
            this.tabControlPanel1.Controls.Add(this.lbl_x21);
            this.tabControlPanel1.Controls.Add(this.lbl_x20);
            this.tabControlPanel1.Controls.Add(this.lbl_x17);
            this.tabControlPanel1.Controls.Add(this.lbl_x16);
            this.tabControlPanel1.Controls.Add(this.lbl_x15);
            this.tabControlPanel1.Controls.Add(this.lbl_x14);
            this.tabControlPanel1.Controls.Add(this.lbl_x13);
            this.tabControlPanel1.Controls.Add(this.lbl_x12);
            this.tabControlPanel1.Controls.Add(this.lbl_x7);
            this.tabControlPanel1.Controls.Add(this.lbl_x6);
            this.tabControlPanel1.Controls.Add(this.lbl_x5);
            this.tabControlPanel1.Controls.Add(this.lbl_x4);
            this.tabControlPanel1.Controls.Add(this.lbl_x3);
            this.tabControlPanel1.Controls.Add(this.lbl_x2);
            this.tabControlPanel1.Controls.Add(this.lbl_x1);
            this.tabControlPanel1.Controls.Add(this.lbl_x11);
            this.tabControlPanel1.Controls.Add(this.lbl_x10);
            this.tabControlPanel1.Controls.Add(this.lbl_x0);
            this.tabControlPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel1.Location = new System.Drawing.Point(0, 28);
            this.tabControlPanel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabControlPanel1.Name = "tabControlPanel1";
            this.tabControlPanel1.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel1.Size = new System.Drawing.Size(817, 617);
            this.tabControlPanel1.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(179)))), ((int)(((byte)(231)))));
            this.tabControlPanel1.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(237)))), ((int)(((byte)(254)))));
            this.tabControlPanel1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel1.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(97)))), ((int)(((byte)(156)))));
            this.tabControlPanel1.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right) 
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel1.Style.GradientAngle = 90;
            this.tabControlPanel1.TabIndex = 1;
            this.tabControlPanel1.TabItem = this.tabItem1;
            this.tabControlPanel1.Click += new System.EventHandler(this.tabControlPanel1_Click);
            // 
            // uLan_x42
            // 
            this.uLan_x42.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x42.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x42.Location = new System.Drawing.Point(14, 369);
            this.uLan_x42.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.uLan_x42.Name = "uLan_x42";
            this.uLan_x42.Size = new System.Drawing.Size(26, 23);
            this.uLan_x42.TabIndex = 221;
            // 
            // uLan_x43
            // 
            this.uLan_x43.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x43.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x43.Location = new System.Drawing.Point(14, 400);
            this.uLan_x43.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.uLan_x43.Name = "uLan_x43";
            this.uLan_x43.Size = new System.Drawing.Size(26, 23);
            this.uLan_x43.TabIndex = 220;
            // 
            // uLan_x45
            // 
            this.uLan_x45.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x45.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x45.Location = new System.Drawing.Point(14, 462);
            this.uLan_x45.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.uLan_x45.Name = "uLan_x45";
            this.uLan_x45.Size = new System.Drawing.Size(26, 23);
            this.uLan_x45.TabIndex = 219;
            // 
            // uLan_x46
            // 
            this.uLan_x46.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x46.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x46.Location = new System.Drawing.Point(14, 494);
            this.uLan_x46.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.uLan_x46.Name = "uLan_x46";
            this.uLan_x46.Size = new System.Drawing.Size(26, 23);
            this.uLan_x46.TabIndex = 218;
            // 
            // uLan_x44
            // 
            this.uLan_x44.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x44.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x44.Location = new System.Drawing.Point(14, 431);
            this.uLan_x44.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.uLan_x44.Name = "uLan_x44";
            this.uLan_x44.Size = new System.Drawing.Size(26, 23);
            this.uLan_x44.TabIndex = 217;
            // 
            // uLan_x41
            // 
            this.uLan_x41.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x41.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x41.Location = new System.Drawing.Point(14, 338);
            this.uLan_x41.Margin = new System.Windows.Forms.Padding(14, 38, 14, 38);
            this.uLan_x41.Name = "uLan_x41";
            this.uLan_x41.Size = new System.Drawing.Size(26, 23);
            this.uLan_x41.TabIndex = 216;
            // 
            // uLan_x40
            // 
            this.uLan_x40.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x40.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x40.Location = new System.Drawing.Point(14, 306);
            this.uLan_x40.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_x40.Name = "uLan_x40";
            this.uLan_x40.Size = new System.Drawing.Size(26, 23);
            this.uLan_x40.TabIndex = 215;
            // 
            // uLan_x47
            // 
            this.uLan_x47.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x47.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x47.Location = new System.Drawing.Point(14, 525);
            this.uLan_x47.Margin = new System.Windows.Forms.Padding(9, 23, 9, 23);
            this.uLan_x47.Name = "uLan_x47";
            this.uLan_x47.Size = new System.Drawing.Size(26, 23);
            this.uLan_x47.TabIndex = 214;
            // 
            // uLan_x52
            // 
            this.uLan_x52.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x52.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x52.Location = new System.Drawing.Point(199, 369);
            this.uLan_x52.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.uLan_x52.Name = "uLan_x52";
            this.uLan_x52.Size = new System.Drawing.Size(26, 23);
            this.uLan_x52.TabIndex = 213;
            // 
            // uLan_x53
            // 
            this.uLan_x53.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x53.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x53.Location = new System.Drawing.Point(199, 400);
            this.uLan_x53.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.uLan_x53.Name = "uLan_x53";
            this.uLan_x53.Size = new System.Drawing.Size(26, 23);
            this.uLan_x53.TabIndex = 212;
            // 
            // uLan_x55
            // 
            this.uLan_x55.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x55.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x55.Location = new System.Drawing.Point(199, 462);
            this.uLan_x55.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.uLan_x55.Name = "uLan_x55";
            this.uLan_x55.Size = new System.Drawing.Size(26, 23);
            this.uLan_x55.TabIndex = 211;
            // 
            // uLan_x56
            // 
            this.uLan_x56.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x56.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x56.Location = new System.Drawing.Point(199, 494);
            this.uLan_x56.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.uLan_x56.Name = "uLan_x56";
            this.uLan_x56.Size = new System.Drawing.Size(26, 23);
            this.uLan_x56.TabIndex = 210;
            // 
            // uLan_x54
            // 
            this.uLan_x54.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x54.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x54.Location = new System.Drawing.Point(199, 431);
            this.uLan_x54.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.uLan_x54.Name = "uLan_x54";
            this.uLan_x54.Size = new System.Drawing.Size(26, 23);
            this.uLan_x54.TabIndex = 209;
            // 
            // uLan_x51
            // 
            this.uLan_x51.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x51.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x51.Location = new System.Drawing.Point(199, 338);
            this.uLan_x51.Margin = new System.Windows.Forms.Padding(14, 38, 14, 38);
            this.uLan_x51.Name = "uLan_x51";
            this.uLan_x51.Size = new System.Drawing.Size(26, 23);
            this.uLan_x51.TabIndex = 208;
            // 
            // uLan_x50
            // 
            this.uLan_x50.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x50.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x50.Location = new System.Drawing.Point(199, 306);
            this.uLan_x50.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_x50.Name = "uLan_x50";
            this.uLan_x50.Size = new System.Drawing.Size(26, 23);
            this.uLan_x50.TabIndex = 207;
            // 
            // uLan_x57
            // 
            this.uLan_x57.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x57.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x57.Location = new System.Drawing.Point(199, 525);
            this.uLan_x57.Margin = new System.Windows.Forms.Padding(9, 23, 9, 23);
            this.uLan_x57.Name = "uLan_x57";
            this.uLan_x57.Size = new System.Drawing.Size(26, 23);
            this.uLan_x57.TabIndex = 206;
            // 
            // uLan_x72
            // 
            this.uLan_x72.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x72.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x72.Location = new System.Drawing.Point(592, 369);
            this.uLan_x72.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.uLan_x72.Name = "uLan_x72";
            this.uLan_x72.Size = new System.Drawing.Size(26, 23);
            this.uLan_x72.TabIndex = 205;
            // 
            // uLan_x73
            // 
            this.uLan_x73.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x73.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x73.Location = new System.Drawing.Point(592, 400);
            this.uLan_x73.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.uLan_x73.Name = "uLan_x73";
            this.uLan_x73.Size = new System.Drawing.Size(26, 23);
            this.uLan_x73.TabIndex = 204;
            // 
            // uLan_x75
            // 
            this.uLan_x75.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x75.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x75.Location = new System.Drawing.Point(592, 462);
            this.uLan_x75.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.uLan_x75.Name = "uLan_x75";
            this.uLan_x75.Size = new System.Drawing.Size(26, 23);
            this.uLan_x75.TabIndex = 203;
            // 
            // uLan_x76
            // 
            this.uLan_x76.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x76.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x76.Location = new System.Drawing.Point(592, 494);
            this.uLan_x76.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.uLan_x76.Name = "uLan_x76";
            this.uLan_x76.Size = new System.Drawing.Size(26, 23);
            this.uLan_x76.TabIndex = 202;
            // 
            // uLan_x74
            // 
            this.uLan_x74.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x74.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x74.Location = new System.Drawing.Point(592, 431);
            this.uLan_x74.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.uLan_x74.Name = "uLan_x74";
            this.uLan_x74.Size = new System.Drawing.Size(26, 23);
            this.uLan_x74.TabIndex = 201;
            // 
            // uLan_x71
            // 
            this.uLan_x71.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x71.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x71.Location = new System.Drawing.Point(592, 338);
            this.uLan_x71.Margin = new System.Windows.Forms.Padding(14, 38, 14, 38);
            this.uLan_x71.Name = "uLan_x71";
            this.uLan_x71.Size = new System.Drawing.Size(26, 23);
            this.uLan_x71.TabIndex = 200;
            // 
            // uLan_x70
            // 
            this.uLan_x70.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x70.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x70.Location = new System.Drawing.Point(592, 306);
            this.uLan_x70.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_x70.Name = "uLan_x70";
            this.uLan_x70.Size = new System.Drawing.Size(26, 23);
            this.uLan_x70.TabIndex = 199;
            // 
            // uLan_x77
            // 
            this.uLan_x77.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x77.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x77.Location = new System.Drawing.Point(592, 525);
            this.uLan_x77.Margin = new System.Windows.Forms.Padding(9, 23, 9, 23);
            this.uLan_x77.Name = "uLan_x77";
            this.uLan_x77.Size = new System.Drawing.Size(26, 23);
            this.uLan_x77.TabIndex = 198;
            // 
            // uLan_x62
            // 
            this.uLan_x62.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x62.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x62.Location = new System.Drawing.Point(397, 369);
            this.uLan_x62.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_x62.Name = "uLan_x62";
            this.uLan_x62.Size = new System.Drawing.Size(26, 23);
            this.uLan_x62.TabIndex = 197;
            // 
            // uLan_x63
            // 
            this.uLan_x63.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x63.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x63.Location = new System.Drawing.Point(397, 400);
            this.uLan_x63.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_x63.Name = "uLan_x63";
            this.uLan_x63.Size = new System.Drawing.Size(26, 23);
            this.uLan_x63.TabIndex = 196;
            // 
            // uLan_x65
            // 
            this.uLan_x65.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x65.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x65.Location = new System.Drawing.Point(397, 462);
            this.uLan_x65.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_x65.Name = "uLan_x65";
            this.uLan_x65.Size = new System.Drawing.Size(26, 23);
            this.uLan_x65.TabIndex = 195;
            // 
            // uLan_x66
            // 
            this.uLan_x66.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x66.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x66.Location = new System.Drawing.Point(397, 494);
            this.uLan_x66.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_x66.Name = "uLan_x66";
            this.uLan_x66.Size = new System.Drawing.Size(26, 23);
            this.uLan_x66.TabIndex = 194;
            // 
            // uLan_x64
            // 
            this.uLan_x64.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x64.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x64.Location = new System.Drawing.Point(397, 431);
            this.uLan_x64.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_x64.Name = "uLan_x64";
            this.uLan_x64.Size = new System.Drawing.Size(26, 23);
            this.uLan_x64.TabIndex = 193;
            // 
            // uLan_x61
            // 
            this.uLan_x61.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x61.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x61.Location = new System.Drawing.Point(397, 338);
            this.uLan_x61.Margin = new System.Windows.Forms.Padding(9, 23, 9, 23);
            this.uLan_x61.Name = "uLan_x61";
            this.uLan_x61.Size = new System.Drawing.Size(26, 23);
            this.uLan_x61.TabIndex = 192;
            // 
            // uLan_x60
            // 
            this.uLan_x60.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x60.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x60.Location = new System.Drawing.Point(397, 306);
            this.uLan_x60.Margin = new System.Windows.Forms.Padding(8, 18, 8, 18);
            this.uLan_x60.Name = "uLan_x60";
            this.uLan_x60.Size = new System.Drawing.Size(26, 23);
            this.uLan_x60.TabIndex = 191;
            // 
            // uLan_x67
            // 
            this.uLan_x67.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x67.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x67.Location = new System.Drawing.Point(397, 525);
            this.uLan_x67.Margin = new System.Windows.Forms.Padding(6, 14, 6, 14);
            this.uLan_x67.Name = "uLan_x67";
            this.uLan_x67.Size = new System.Drawing.Size(26, 23);
            this.uLan_x67.TabIndex = 190;
            // 
            // uLan_x32
            // 
            this.uLan_x32.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x32.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x32.Location = new System.Drawing.Point(591, 81);
            this.uLan_x32.Margin = new System.Windows.Forms.Padding(14, 38, 14, 38);
            this.uLan_x32.Name = "uLan_x32";
            this.uLan_x32.Size = new System.Drawing.Size(26, 23);
            this.uLan_x32.TabIndex = 189;
            // 
            // uLan_x33
            // 
            this.uLan_x33.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x33.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x33.Location = new System.Drawing.Point(591, 113);
            this.uLan_x33.Margin = new System.Windows.Forms.Padding(14, 38, 14, 38);
            this.uLan_x33.Name = "uLan_x33";
            this.uLan_x33.Size = new System.Drawing.Size(26, 23);
            this.uLan_x33.TabIndex = 188;
            // 
            // uLan_x35
            // 
            this.uLan_x35.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x35.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x35.Location = new System.Drawing.Point(591, 177);
            this.uLan_x35.Margin = new System.Windows.Forms.Padding(14, 38, 14, 38);
            this.uLan_x35.Name = "uLan_x35";
            this.uLan_x35.Size = new System.Drawing.Size(26, 23);
            this.uLan_x35.TabIndex = 187;
            // 
            // uLan_x36
            // 
            this.uLan_x36.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x36.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x36.Location = new System.Drawing.Point(591, 209);
            this.uLan_x36.Margin = new System.Windows.Forms.Padding(14, 38, 14, 38);
            this.uLan_x36.Name = "uLan_x36";
            this.uLan_x36.Size = new System.Drawing.Size(26, 23);
            this.uLan_x36.TabIndex = 186;
            // 
            // uLan_x34
            // 
            this.uLan_x34.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x34.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x34.Location = new System.Drawing.Point(591, 145);
            this.uLan_x34.Margin = new System.Windows.Forms.Padding(14, 38, 14, 38);
            this.uLan_x34.Name = "uLan_x34";
            this.uLan_x34.Size = new System.Drawing.Size(26, 23);
            this.uLan_x34.TabIndex = 185;
            // 
            // uLan_x31
            // 
            this.uLan_x31.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x31.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x31.Location = new System.Drawing.Point(591, 49);
            this.uLan_x31.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_x31.Name = "uLan_x31";
            this.uLan_x31.Size = new System.Drawing.Size(26, 23);
            this.uLan_x31.TabIndex = 184;
            // 
            // uLan_x30
            // 
            this.uLan_x30.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x30.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x30.Location = new System.Drawing.Point(591, 17);
            this.uLan_x30.Margin = new System.Windows.Forms.Padding(9, 23, 9, 23);
            this.uLan_x30.Name = "uLan_x30";
            this.uLan_x30.Size = new System.Drawing.Size(26, 23);
            this.uLan_x30.TabIndex = 183;
            // 
            // uLan_x37
            // 
            this.uLan_x37.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x37.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x37.Location = new System.Drawing.Point(591, 238);
            this.uLan_x37.Margin = new System.Windows.Forms.Padding(8, 18, 8, 18);
            this.uLan_x37.Name = "uLan_x37";
            this.uLan_x37.Size = new System.Drawing.Size(26, 23);
            this.uLan_x37.TabIndex = 182;
            // 
            // uLan_x22
            // 
            this.uLan_x22.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x22.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x22.Location = new System.Drawing.Point(400, 81);
            this.uLan_x22.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_x22.Name = "uLan_x22";
            this.uLan_x22.Size = new System.Drawing.Size(26, 23);
            this.uLan_x22.TabIndex = 181;
            // 
            // uLan_x23
            // 
            this.uLan_x23.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x23.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x23.Location = new System.Drawing.Point(400, 113);
            this.uLan_x23.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_x23.Name = "uLan_x23";
            this.uLan_x23.Size = new System.Drawing.Size(26, 23);
            this.uLan_x23.TabIndex = 180;
            // 
            // uLan_x25
            // 
            this.uLan_x25.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x25.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x25.Location = new System.Drawing.Point(400, 177);
            this.uLan_x25.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_x25.Name = "uLan_x25";
            this.uLan_x25.Size = new System.Drawing.Size(26, 23);
            this.uLan_x25.TabIndex = 179;
            // 
            // uLan_x26
            // 
            this.uLan_x26.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x26.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x26.Location = new System.Drawing.Point(400, 209);
            this.uLan_x26.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_x26.Name = "uLan_x26";
            this.uLan_x26.Size = new System.Drawing.Size(26, 23);
            this.uLan_x26.TabIndex = 178;
            // 
            // uLan_x24
            // 
            this.uLan_x24.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x24.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x24.Location = new System.Drawing.Point(400, 145);
            this.uLan_x24.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_x24.Name = "uLan_x24";
            this.uLan_x24.Size = new System.Drawing.Size(26, 23);
            this.uLan_x24.TabIndex = 177;
            // 
            // uLan_x21
            // 
            this.uLan_x21.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x21.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x21.Location = new System.Drawing.Point(400, 49);
            this.uLan_x21.Margin = new System.Windows.Forms.Padding(9, 23, 9, 23);
            this.uLan_x21.Name = "uLan_x21";
            this.uLan_x21.Size = new System.Drawing.Size(26, 23);
            this.uLan_x21.TabIndex = 176;
            // 
            // uLan_x20
            // 
            this.uLan_x20.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x20.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x20.Location = new System.Drawing.Point(400, 17);
            this.uLan_x20.Margin = new System.Windows.Forms.Padding(8, 18, 8, 18);
            this.uLan_x20.Name = "uLan_x20";
            this.uLan_x20.Size = new System.Drawing.Size(26, 23);
            this.uLan_x20.TabIndex = 175;
            // 
            // uLan_x27
            // 
            this.uLan_x27.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x27.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x27.Location = new System.Drawing.Point(400, 238);
            this.uLan_x27.Margin = new System.Windows.Forms.Padding(6, 14, 6, 14);
            this.uLan_x27.Name = "uLan_x27";
            this.uLan_x27.Size = new System.Drawing.Size(26, 23);
            this.uLan_x27.TabIndex = 174;
            // 
            // uLan_x12
            // 
            this.uLan_x12.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x12.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x12.Location = new System.Drawing.Point(199, 81);
            this.uLan_x12.Margin = new System.Windows.Forms.Padding(9, 23, 9, 23);
            this.uLan_x12.Name = "uLan_x12";
            this.uLan_x12.Size = new System.Drawing.Size(26, 23);
            this.uLan_x12.TabIndex = 173;
            // 
            // uLan_x13
            // 
            this.uLan_x13.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x13.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x13.Location = new System.Drawing.Point(199, 113);
            this.uLan_x13.Margin = new System.Windows.Forms.Padding(9, 23, 9, 23);
            this.uLan_x13.Name = "uLan_x13";
            this.uLan_x13.Size = new System.Drawing.Size(26, 23);
            this.uLan_x13.TabIndex = 172;
            // 
            // uLan_x15
            // 
            this.uLan_x15.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x15.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x15.Location = new System.Drawing.Point(199, 177);
            this.uLan_x15.Margin = new System.Windows.Forms.Padding(9, 23, 9, 23);
            this.uLan_x15.Name = "uLan_x15";
            this.uLan_x15.Size = new System.Drawing.Size(26, 23);
            this.uLan_x15.TabIndex = 171;
            // 
            // uLan_x16
            // 
            this.uLan_x16.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x16.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x16.Location = new System.Drawing.Point(199, 209);
            this.uLan_x16.Margin = new System.Windows.Forms.Padding(9, 23, 9, 23);
            this.uLan_x16.Name = "uLan_x16";
            this.uLan_x16.Size = new System.Drawing.Size(26, 23);
            this.uLan_x16.TabIndex = 170;
            // 
            // uLan_x14
            // 
            this.uLan_x14.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x14.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x14.Location = new System.Drawing.Point(199, 145);
            this.uLan_x14.Margin = new System.Windows.Forms.Padding(9, 23, 9, 23);
            this.uLan_x14.Name = "uLan_x14";
            this.uLan_x14.Size = new System.Drawing.Size(26, 23);
            this.uLan_x14.TabIndex = 169;
            // 
            // uLan_x11
            // 
            this.uLan_x11.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x11.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x11.Location = new System.Drawing.Point(199, 49);
            this.uLan_x11.Margin = new System.Windows.Forms.Padding(8, 18, 8, 18);
            this.uLan_x11.Name = "uLan_x11";
            this.uLan_x11.Size = new System.Drawing.Size(26, 23);
            this.uLan_x11.TabIndex = 168;
            // 
            // uLan_x10
            // 
            this.uLan_x10.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x10.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x10.Location = new System.Drawing.Point(199, 17);
            this.uLan_x10.Margin = new System.Windows.Forms.Padding(6, 14, 6, 14);
            this.uLan_x10.Name = "uLan_x10";
            this.uLan_x10.Size = new System.Drawing.Size(26, 23);
            this.uLan_x10.TabIndex = 167;
            // 
            // uLan_x17
            // 
            this.uLan_x17.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x17.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x17.Location = new System.Drawing.Point(199, 238);
            this.uLan_x17.Margin = new System.Windows.Forms.Padding(4, 11, 4, 11);
            this.uLan_x17.Name = "uLan_x17";
            this.uLan_x17.Size = new System.Drawing.Size(26, 23);
            this.uLan_x17.TabIndex = 166;
            // 
            // uLan_x2
            // 
            this.uLan_x2.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x2.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x2.Location = new System.Drawing.Point(10, 81);
            this.uLan_x2.Margin = new System.Windows.Forms.Padding(8, 18, 8, 18);
            this.uLan_x2.Name = "uLan_x2";
            this.uLan_x2.Size = new System.Drawing.Size(26, 23);
            this.uLan_x2.TabIndex = 165;
            // 
            // uLan_x3
            // 
            this.uLan_x3.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x3.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x3.Location = new System.Drawing.Point(10, 113);
            this.uLan_x3.Margin = new System.Windows.Forms.Padding(8, 18, 8, 18);
            this.uLan_x3.Name = "uLan_x3";
            this.uLan_x3.Size = new System.Drawing.Size(26, 23);
            this.uLan_x3.TabIndex = 164;
            // 
            // uLan_x5
            // 
            this.uLan_x5.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x5.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x5.Location = new System.Drawing.Point(10, 177);
            this.uLan_x5.Margin = new System.Windows.Forms.Padding(8, 18, 8, 18);
            this.uLan_x5.Name = "uLan_x5";
            this.uLan_x5.Size = new System.Drawing.Size(26, 23);
            this.uLan_x5.TabIndex = 163;
            // 
            // uLan_x6
            // 
            this.uLan_x6.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x6.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x6.Location = new System.Drawing.Point(10, 209);
            this.uLan_x6.Margin = new System.Windows.Forms.Padding(8, 18, 8, 18);
            this.uLan_x6.Name = "uLan_x6";
            this.uLan_x6.Size = new System.Drawing.Size(26, 23);
            this.uLan_x6.TabIndex = 162;
            // 
            // uLan_x4
            // 
            this.uLan_x4.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x4.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x4.Location = new System.Drawing.Point(10, 145);
            this.uLan_x4.Margin = new System.Windows.Forms.Padding(8, 18, 8, 18);
            this.uLan_x4.Name = "uLan_x4";
            this.uLan_x4.Size = new System.Drawing.Size(26, 23);
            this.uLan_x4.TabIndex = 161;
            // 
            // uLan_x1
            // 
            this.uLan_x1.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x1.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x1.Location = new System.Drawing.Point(10, 49);
            this.uLan_x1.Margin = new System.Windows.Forms.Padding(6, 14, 6, 14);
            this.uLan_x1.Name = "uLan_x1";
            this.uLan_x1.Size = new System.Drawing.Size(26, 23);
            this.uLan_x1.TabIndex = 160;
            // 
            // uLan_x0
            // 
            this.uLan_x0.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x0.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x0.Location = new System.Drawing.Point(10, 17);
            this.uLan_x0.Margin = new System.Windows.Forms.Padding(4, 11, 4, 11);
            this.uLan_x0.Name = "uLan_x0";
            this.uLan_x0.Size = new System.Drawing.Size(26, 23);
            this.uLan_x0.TabIndex = 159;
            // 
            // uLan_x7
            // 
            this.uLan_x7.BackColor = System.Drawing.Color.Transparent;
            this.uLan_x7.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_x7.Location = new System.Drawing.Point(10, 238);
            this.uLan_x7.Margin = new System.Windows.Forms.Padding(4, 9, 4, 9);
            this.uLan_x7.Name = "uLan_x7";
            this.uLan_x7.Size = new System.Drawing.Size(26, 23);
            this.uLan_x7.TabIndex = 158;
            // 
            // lbl_x77
            // 
            this.lbl_x77.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x77.AutoSize = true;
            this.lbl_x77.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x77.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x77.ForeColor = System.Drawing.Color.Black;
            this.lbl_x77.Location = new System.Drawing.Point(622, 530);
            this.lbl_x77.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x77.Name = "lbl_x77";
            this.lbl_x77.Size = new System.Drawing.Size(30, 18);
            this.lbl_x77.TabIndex = 128;
            this.lbl_x77.Text = "X77";
            // 
            // lbl_x76
            // 
            this.lbl_x76.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x76.AutoSize = true;
            this.lbl_x76.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x76.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x76.ForeColor = System.Drawing.Color.Black;
            this.lbl_x76.Location = new System.Drawing.Point(622, 497);
            this.lbl_x76.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x76.Name = "lbl_x76";
            this.lbl_x76.Size = new System.Drawing.Size(132, 18);
            this.lbl_x76.TabIndex = 127;
            this.lbl_x76.Text = "X76  NG分选托盘检测";
            // 
            // lbl_x75
            // 
            this.lbl_x75.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x75.AutoSize = true;
            this.lbl_x75.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x75.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x75.ForeColor = System.Drawing.Color.Black;
            this.lbl_x75.Location = new System.Drawing.Point(622, 466);
            this.lbl_x75.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x75.Name = "lbl_x75";
            this.lbl_x75.Size = new System.Drawing.Size(75, 18);
            this.lbl_x75.TabIndex = 126;
            this.lbl_x75.Text = "X75  真空表";
            // 
            // lbl_x74
            // 
            this.lbl_x74.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x74.AutoSize = true;
            this.lbl_x74.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x74.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x74.ForeColor = System.Drawing.Color.Black;
            this.lbl_x74.Location = new System.Drawing.Point(622, 436);
            this.lbl_x74.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x74.Name = "lbl_x74";
            this.lbl_x74.Size = new System.Drawing.Size(80, 18);
            this.lbl_x74.TabIndex = 125;
            this.lbl_x74.Text = "X74  Y_ALM";
            // 
            // lbl_x73
            // 
            this.lbl_x73.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x73.AutoSize = true;
            this.lbl_x73.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x73.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x73.ForeColor = System.Drawing.Color.Black;
            this.lbl_x73.Location = new System.Drawing.Point(622, 406);
            this.lbl_x73.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x73.Name = "lbl_x73";
            this.lbl_x73.Size = new System.Drawing.Size(81, 18);
            this.lbl_x73.TabIndex = 124;
            this.lbl_x73.Text = "X73  X_ALM";
            // 
            // lbl_x72
            // 
            this.lbl_x72.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x72.AutoSize = true;
            this.lbl_x72.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x72.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x72.ForeColor = System.Drawing.Color.Black;
            this.lbl_x72.Location = new System.Drawing.Point(622, 374);
            this.lbl_x72.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x72.Name = "lbl_x72";
            this.lbl_x72.Size = new System.Drawing.Size(144, 18);
            this.lbl_x72.TabIndex = 123;
            this.lbl_x72.Text = "X72  NG分选旋转气缸伸";
            // 
            // lbl_x71
            // 
            this.lbl_x71.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x71.AutoSize = true;
            this.lbl_x71.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x71.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x71.ForeColor = System.Drawing.Color.Black;
            this.lbl_x71.Location = new System.Drawing.Point(622, 343);
            this.lbl_x71.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x71.Name = "lbl_x71";
            this.lbl_x71.Size = new System.Drawing.Size(144, 18);
            this.lbl_x71.TabIndex = 122;
            this.lbl_x71.Text = "X71  NG分选旋转气缸伸";
            // 
            // lbl_x70
            // 
            this.lbl_x70.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x70.AutoSize = true;
            this.lbl_x70.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x70.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x70.ForeColor = System.Drawing.Color.Black;
            this.lbl_x70.Location = new System.Drawing.Point(622, 310);
            this.lbl_x70.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x70.Name = "lbl_x70";
            this.lbl_x70.Size = new System.Drawing.Size(140, 18);
            this.lbl_x70.TabIndex = 121;
            this.lbl_x70.Text = "X70  NG分选Z轴气缸缩";
            // 
            // lbl_x67
            // 
            this.lbl_x67.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x67.AutoSize = true;
            this.lbl_x67.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x67.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x67.ForeColor = System.Drawing.Color.Black;
            this.lbl_x67.Location = new System.Drawing.Point(428, 530);
            this.lbl_x67.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x67.Name = "lbl_x67";
            this.lbl_x67.Size = new System.Drawing.Size(30, 18);
            this.lbl_x67.TabIndex = 120;
            this.lbl_x67.Text = "X67";
            // 
            // lbl_x66
            // 
            this.lbl_x66.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x66.AutoSize = true;
            this.lbl_x66.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x66.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x66.ForeColor = System.Drawing.Color.Black;
            this.lbl_x66.Location = new System.Drawing.Point(428, 497);
            this.lbl_x66.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x66.Name = "lbl_x66";
            this.lbl_x66.Size = new System.Drawing.Size(30, 18);
            this.lbl_x66.TabIndex = 119;
            this.lbl_x66.Text = "X66";
            // 
            // lbl_x65
            // 
            this.lbl_x65.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x65.AutoSize = true;
            this.lbl_x65.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x65.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x65.ForeColor = System.Drawing.Color.Black;
            this.lbl_x65.Location = new System.Drawing.Point(428, 466);
            this.lbl_x65.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x65.Name = "lbl_x65";
            this.lbl_x65.Size = new System.Drawing.Size(30, 18);
            this.lbl_x65.TabIndex = 118;
            this.lbl_x65.Text = "X65";
            // 
            // lbl_x64
            // 
            this.lbl_x64.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x64.AutoSize = true;
            this.lbl_x64.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x64.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x64.ForeColor = System.Drawing.Color.Black;
            this.lbl_x64.Location = new System.Drawing.Point(428, 436);
            this.lbl_x64.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x64.Name = "lbl_x64";
            this.lbl_x64.Size = new System.Drawing.Size(30, 18);
            this.lbl_x64.TabIndex = 117;
            this.lbl_x64.Text = "X64";
            // 
            // lbl_x63
            // 
            this.lbl_x63.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x63.AutoSize = true;
            this.lbl_x63.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x63.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x63.ForeColor = System.Drawing.Color.Black;
            this.lbl_x63.Location = new System.Drawing.Point(428, 406);
            this.lbl_x63.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x63.Name = "lbl_x63";
            this.lbl_x63.Size = new System.Drawing.Size(30, 18);
            this.lbl_x63.TabIndex = 116;
            this.lbl_x63.Text = "X63";
            // 
            // lbl_x62
            // 
            this.lbl_x62.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x62.AutoSize = true;
            this.lbl_x62.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x62.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x62.ForeColor = System.Drawing.Color.Black;
            this.lbl_x62.Location = new System.Drawing.Point(428, 374);
            this.lbl_x62.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x62.Name = "lbl_x62";
            this.lbl_x62.Size = new System.Drawing.Size(30, 18);
            this.lbl_x62.TabIndex = 115;
            this.lbl_x62.Text = "X62";
            // 
            // lbl_x61
            // 
            this.lbl_x61.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x61.AutoSize = true;
            this.lbl_x61.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x61.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x61.ForeColor = System.Drawing.Color.Black;
            this.lbl_x61.Location = new System.Drawing.Point(428, 343);
            this.lbl_x61.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x61.Name = "lbl_x61";
            this.lbl_x61.Size = new System.Drawing.Size(30, 18);
            this.lbl_x61.TabIndex = 114;
            this.lbl_x61.Text = "X61";
            // 
            // lbl_x60
            // 
            this.lbl_x60.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x60.AutoSize = true;
            this.lbl_x60.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x60.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x60.ForeColor = System.Drawing.Color.Black;
            this.lbl_x60.Location = new System.Drawing.Point(428, 310);
            this.lbl_x60.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x60.Name = "lbl_x60";
            this.lbl_x60.Size = new System.Drawing.Size(65, 18);
            this.lbl_x60.TabIndex = 113;
            this.lbl_x60.Text = "X60  Text";
            // 
            // lbl_x57
            // 
            this.lbl_x57.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x57.AutoSize = true;
            this.lbl_x57.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x57.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x57.ForeColor = System.Drawing.Color.Black;
            this.lbl_x57.Location = new System.Drawing.Point(230, 530);
            this.lbl_x57.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x57.Name = "lbl_x57";
            this.lbl_x57.Size = new System.Drawing.Size(30, 18);
            this.lbl_x57.TabIndex = 112;
            this.lbl_x57.Text = "X57";
            // 
            // lbl_x56
            // 
            this.lbl_x56.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x56.AutoSize = true;
            this.lbl_x56.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x56.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x56.ForeColor = System.Drawing.Color.Black;
            this.lbl_x56.Location = new System.Drawing.Point(230, 497);
            this.lbl_x56.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x56.Name = "lbl_x56";
            this.lbl_x56.Size = new System.Drawing.Size(30, 18);
            this.lbl_x56.TabIndex = 111;
            this.lbl_x56.Text = "X56";
            // 
            // lbl_x55
            // 
            this.lbl_x55.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x55.AutoSize = true;
            this.lbl_x55.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x55.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x55.ForeColor = System.Drawing.Color.Black;
            this.lbl_x55.Location = new System.Drawing.Point(230, 466);
            this.lbl_x55.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x55.Name = "lbl_x55";
            this.lbl_x55.Size = new System.Drawing.Size(30, 18);
            this.lbl_x55.TabIndex = 110;
            this.lbl_x55.Text = "X55";
            // 
            // lbl_x54
            // 
            this.lbl_x54.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x54.AutoSize = true;
            this.lbl_x54.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x54.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x54.ForeColor = System.Drawing.Color.Black;
            this.lbl_x54.Location = new System.Drawing.Point(230, 436);
            this.lbl_x54.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x54.Name = "lbl_x54";
            this.lbl_x54.Size = new System.Drawing.Size(30, 18);
            this.lbl_x54.TabIndex = 109;
            this.lbl_x54.Text = "X54";
            // 
            // lbl_x53
            // 
            this.lbl_x53.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x53.AutoSize = true;
            this.lbl_x53.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x53.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x53.ForeColor = System.Drawing.Color.Black;
            this.lbl_x53.Location = new System.Drawing.Point(230, 406);
            this.lbl_x53.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x53.Name = "lbl_x53";
            this.lbl_x53.Size = new System.Drawing.Size(30, 18);
            this.lbl_x53.TabIndex = 108;
            this.lbl_x53.Text = "X53";
            // 
            // lbl_x52
            // 
            this.lbl_x52.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x52.AutoSize = true;
            this.lbl_x52.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x52.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x52.ForeColor = System.Drawing.Color.Black;
            this.lbl_x52.Location = new System.Drawing.Point(230, 374);
            this.lbl_x52.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x52.Name = "lbl_x52";
            this.lbl_x52.Size = new System.Drawing.Size(149, 18);
            this.lbl_x52.TabIndex = 107;
            this.lbl_x52.Text = "X52  扫码取料位托盘检测";
            // 
            // lbl_x51
            // 
            this.lbl_x51.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x51.AutoSize = true;
            this.lbl_x51.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x51.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x51.ForeColor = System.Drawing.Color.Black;
            this.lbl_x51.Location = new System.Drawing.Point(230, 343);
            this.lbl_x51.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x51.Name = "lbl_x51";
            this.lbl_x51.Size = new System.Drawing.Size(137, 18);
            this.lbl_x51.TabIndex = 106;
            this.lbl_x51.Text = "X51  扫码切换气缸右缩";
            // 
            // lbl_x50
            // 
            this.lbl_x50.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x50.AutoSize = true;
            this.lbl_x50.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x50.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x50.ForeColor = System.Drawing.Color.Black;
            this.lbl_x50.Location = new System.Drawing.Point(230, 311);
            this.lbl_x50.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x50.Name = "lbl_x50";
            this.lbl_x50.Size = new System.Drawing.Size(137, 18);
            this.lbl_x50.TabIndex = 105;
            this.lbl_x50.Text = "X50  扫码切换气缸右伸";
            // 
            // lbl_x47
            // 
            this.lbl_x47.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x47.AutoSize = true;
            this.lbl_x47.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x47.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x47.ForeColor = System.Drawing.Color.Black;
            this.lbl_x47.Location = new System.Drawing.Point(40, 530);
            this.lbl_x47.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x47.Name = "lbl_x47";
            this.lbl_x47.Size = new System.Drawing.Size(137, 18);
            this.lbl_x47.TabIndex = 104;
            this.lbl_x47.Text = "X47  扫码压合气缸左缩";
            // 
            // lbl_x46
            // 
            this.lbl_x46.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x46.AutoSize = true;
            this.lbl_x46.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x46.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x46.ForeColor = System.Drawing.Color.Black;
            this.lbl_x46.Location = new System.Drawing.Point(40, 498);
            this.lbl_x46.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x46.Name = "lbl_x46";
            this.lbl_x46.Size = new System.Drawing.Size(137, 18);
            this.lbl_x46.TabIndex = 103;
            this.lbl_x46.Text = "X46  扫码压合气缸左伸";
            // 
            // lbl_x45
            // 
            this.lbl_x45.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x45.AutoSize = true;
            this.lbl_x45.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x45.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x45.ForeColor = System.Drawing.Color.Black;
            this.lbl_x45.Location = new System.Drawing.Point(40, 466);
            this.lbl_x45.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x45.Name = "lbl_x45";
            this.lbl_x45.Size = new System.Drawing.Size(137, 18);
            this.lbl_x45.TabIndex = 102;
            this.lbl_x45.Text = "X45  扫码移位气缸右缩";
            // 
            // lbl_x44
            // 
            this.lbl_x44.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x44.AutoSize = true;
            this.lbl_x44.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x44.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x44.ForeColor = System.Drawing.Color.Black;
            this.lbl_x44.Location = new System.Drawing.Point(40, 436);
            this.lbl_x44.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x44.Name = "lbl_x44";
            this.lbl_x44.Size = new System.Drawing.Size(137, 18);
            this.lbl_x44.TabIndex = 101;
            this.lbl_x44.Text = "X44  扫码移位气缸右伸";
            // 
            // lbl_x43
            // 
            this.lbl_x43.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x43.AutoSize = true;
            this.lbl_x43.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x43.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x43.ForeColor = System.Drawing.Color.Black;
            this.lbl_x43.Location = new System.Drawing.Point(40, 406);
            this.lbl_x43.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x43.Name = "lbl_x43";
            this.lbl_x43.Size = new System.Drawing.Size(137, 18);
            this.lbl_x43.TabIndex = 100;
            this.lbl_x43.Text = "X43  扫码移位气缸左缩";
            // 
            // lbl_x42
            // 
            this.lbl_x42.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x42.AutoSize = true;
            this.lbl_x42.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x42.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x42.ForeColor = System.Drawing.Color.Black;
            this.lbl_x42.Location = new System.Drawing.Point(40, 374);
            this.lbl_x42.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x42.Name = "lbl_x42";
            this.lbl_x42.Size = new System.Drawing.Size(137, 18);
            this.lbl_x42.TabIndex = 99;
            this.lbl_x42.Text = "X42  扫码移位气缸左伸";
            // 
            // lbl_x41
            // 
            this.lbl_x41.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x41.AutoSize = true;
            this.lbl_x41.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x41.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x41.ForeColor = System.Drawing.Color.Black;
            this.lbl_x41.Location = new System.Drawing.Point(40, 343);
            this.lbl_x41.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x41.Name = "lbl_x41";
            this.lbl_x41.Size = new System.Drawing.Size(137, 18);
            this.lbl_x41.TabIndex = 98;
            this.lbl_x41.Text = "X41  扫码定位气缸后缩";
            // 
            // lbl_x40
            // 
            this.lbl_x40.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x40.AutoSize = true;
            this.lbl_x40.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x40.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x40.ForeColor = System.Drawing.Color.Black;
            this.lbl_x40.Location = new System.Drawing.Point(40, 310);
            this.lbl_x40.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x40.Name = "lbl_x40";
            this.lbl_x40.Size = new System.Drawing.Size(137, 18);
            this.lbl_x40.TabIndex = 97;
            this.lbl_x40.Text = "X40  扫码定位气缸后伸";
            // 
            // lbl_x37
            // 
            this.lbl_x37.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x37.AutoSize = true;
            this.lbl_x37.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x37.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x37.ForeColor = System.Drawing.Color.Black;
            this.lbl_x37.Location = new System.Drawing.Point(622, 244);
            this.lbl_x37.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x37.Name = "lbl_x37";
            this.lbl_x37.Size = new System.Drawing.Size(137, 18);
            this.lbl_x37.TabIndex = 96;
            this.lbl_x37.Text = "X37  扫码定位气缸前缩";
            // 
            // lbl_x36
            // 
            this.lbl_x36.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x36.AutoSize = true;
            this.lbl_x36.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x36.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x36.ForeColor = System.Drawing.Color.Black;
            this.lbl_x36.Location = new System.Drawing.Point(622, 213);
            this.lbl_x36.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x36.Name = "lbl_x36";
            this.lbl_x36.Size = new System.Drawing.Size(137, 18);
            this.lbl_x36.TabIndex = 95;
            this.lbl_x36.Text = "X36  扫码定位气缸前伸";
            // 
            // lbl_x35
            // 
            this.lbl_x35.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x35.AutoSize = true;
            this.lbl_x35.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x35.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x35.ForeColor = System.Drawing.Color.Black;
            this.lbl_x35.Location = new System.Drawing.Point(622, 182);
            this.lbl_x35.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x35.Name = "lbl_x35";
            this.lbl_x35.Size = new System.Drawing.Size(149, 18);
            this.lbl_x35.TabIndex = 94;
            this.lbl_x35.Text = "X35  上料进料口安全光栅";
            // 
            // lbl_x34
            // 
            this.lbl_x34.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x34.AutoSize = true;
            this.lbl_x34.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x34.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x34.ForeColor = System.Drawing.Color.Black;
            this.lbl_x34.Location = new System.Drawing.Point(622, 150);
            this.lbl_x34.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x34.Name = "lbl_x34";
            this.lbl_x34.Size = new System.Drawing.Size(137, 18);
            this.lbl_x34.TabIndex = 93;
            this.lbl_x34.Text = "X34  上料夹爪是否有料";
            // 
            // lbl_x33
            // 
            this.lbl_x33.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x33.AutoSize = true;
            this.lbl_x33.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x33.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x33.ForeColor = System.Drawing.Color.Black;
            this.lbl_x33.Location = new System.Drawing.Point(622, 118);
            this.lbl_x33.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x33.Name = "lbl_x33";
            this.lbl_x33.Size = new System.Drawing.Size(112, 18);
            this.lbl_x33.TabIndex = 92;
            this.lbl_x33.Text = "X33  上料托盘到位";
            // 
            // lbl_x32
            // 
            this.lbl_x32.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x32.AutoSize = true;
            this.lbl_x32.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x32.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x32.ForeColor = System.Drawing.Color.Black;
            this.lbl_x32.Location = new System.Drawing.Point(622, 86);
            this.lbl_x32.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x32.Name = "lbl_x32";
            this.lbl_x32.Size = new System.Drawing.Size(112, 18);
            this.lbl_x32.TabIndex = 91;
            this.lbl_x32.Text = "X32  上料托盘检测";
            // 
            // lbl_x31
            // 
            this.lbl_x31.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x31.AutoSize = true;
            this.lbl_x31.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x31.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x31.ForeColor = System.Drawing.Color.Black;
            this.lbl_x31.Location = new System.Drawing.Point(622, 54);
            this.lbl_x31.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x31.Name = "lbl_x31";
            this.lbl_x31.Size = new System.Drawing.Size(137, 18);
            this.lbl_x31.TabIndex = 90;
            this.lbl_x31.Text = "X31  上料移位气缸右伸";
            // 
            // lbl_x27
            // 
            this.lbl_x27.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x27.AutoSize = true;
            this.lbl_x27.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x27.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x27.ForeColor = System.Drawing.Color.Black;
            this.lbl_x27.Location = new System.Drawing.Point(428, 244);
            this.lbl_x27.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x27.Name = "lbl_x27";
            this.lbl_x27.Size = new System.Drawing.Size(137, 18);
            this.lbl_x27.TabIndex = 88;
            this.lbl_x27.Text = "X27  上料移位气缸左缩";
            // 
            // lbl_x25
            // 
            this.lbl_x25.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x25.AutoSize = true;
            this.lbl_x25.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x25.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x25.ForeColor = System.Drawing.Color.Black;
            this.lbl_x25.Location = new System.Drawing.Point(428, 182);
            this.lbl_x25.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x25.Name = "lbl_x25";
            this.lbl_x25.Size = new System.Drawing.Size(124, 18);
            this.lbl_x25.TabIndex = 86;
            this.lbl_x25.Text = "X25  上料防呆气缸缩";
            // 
            // lbl_x30
            // 
            this.lbl_x30.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x30.AutoSize = true;
            this.lbl_x30.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x30.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x30.ForeColor = System.Drawing.Color.Black;
            this.lbl_x30.Location = new System.Drawing.Point(622, 22);
            this.lbl_x30.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x30.Name = "lbl_x30";
            this.lbl_x30.Size = new System.Drawing.Size(137, 18);
            this.lbl_x30.TabIndex = 89;
            this.lbl_x30.Text = "X30  上料移位气缸右缩";
            // 
            // lbl_x26
            // 
            this.lbl_x26.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x26.AutoSize = true;
            this.lbl_x26.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x26.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x26.ForeColor = System.Drawing.Color.Black;
            this.lbl_x26.Location = new System.Drawing.Point(428, 213);
            this.lbl_x26.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x26.Name = "lbl_x26";
            this.lbl_x26.Size = new System.Drawing.Size(137, 18);
            this.lbl_x26.TabIndex = 87;
            this.lbl_x26.Text = "X26  上料移位气缸左伸";
            // 
            // lbl_x24
            // 
            this.lbl_x24.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x24.AutoSize = true;
            this.lbl_x24.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x24.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x24.ForeColor = System.Drawing.Color.Black;
            this.lbl_x24.Location = new System.Drawing.Point(428, 150);
            this.lbl_x24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x24.Name = "lbl_x24";
            this.lbl_x24.Size = new System.Drawing.Size(124, 18);
            this.lbl_x24.TabIndex = 85;
            this.lbl_x24.Text = "X24  上料防呆气缸伸";
            // 
            // lbl_x23
            // 
            this.lbl_x23.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x23.AutoSize = true;
            this.lbl_x23.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x23.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x23.ForeColor = System.Drawing.Color.Black;
            this.lbl_x23.Location = new System.Drawing.Point(428, 118);
            this.lbl_x23.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x23.Name = "lbl_x23";
            this.lbl_x23.Size = new System.Drawing.Size(137, 18);
            this.lbl_x23.TabIndex = 84;
            this.lbl_x23.Text = "X23  上料后定位气缸缩";
            // 
            // lbl_x22
            // 
            this.lbl_x22.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x22.AutoSize = true;
            this.lbl_x22.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x22.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x22.ForeColor = System.Drawing.Color.Black;
            this.lbl_x22.Location = new System.Drawing.Point(428, 86);
            this.lbl_x22.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x22.Name = "lbl_x22";
            this.lbl_x22.Size = new System.Drawing.Size(137, 18);
            this.lbl_x22.TabIndex = 83;
            this.lbl_x22.Text = "X22  上料后定位气缸伸";
            // 
            // lbl_x21
            // 
            this.lbl_x21.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x21.AutoSize = true;
            this.lbl_x21.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x21.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x21.ForeColor = System.Drawing.Color.Black;
            this.lbl_x21.Location = new System.Drawing.Point(428, 54);
            this.lbl_x21.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x21.Name = "lbl_x21";
            this.lbl_x21.Size = new System.Drawing.Size(137, 18);
            this.lbl_x21.TabIndex = 82;
            this.lbl_x21.Text = "X21  上料前定位气缸缩";
            // 
            // lbl_x20
            // 
            this.lbl_x20.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x20.AutoSize = true;
            this.lbl_x20.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x20.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x20.ForeColor = System.Drawing.Color.Black;
            this.lbl_x20.Location = new System.Drawing.Point(428, 22);
            this.lbl_x20.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x20.Name = "lbl_x20";
            this.lbl_x20.Size = new System.Drawing.Size(137, 18);
            this.lbl_x20.TabIndex = 81;
            this.lbl_x20.Text = "X20  上料前定位气缸伸";
            // 
            // lbl_x17
            // 
            this.lbl_x17.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x17.AutoSize = true;
            this.lbl_x17.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x17.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x17.ForeColor = System.Drawing.Color.Black;
            this.lbl_x17.Location = new System.Drawing.Point(230, 244);
            this.lbl_x17.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x17.Name = "lbl_x17";
            this.lbl_x17.Size = new System.Drawing.Size(145, 18);
            this.lbl_x17.TabIndex = 80;
            this.lbl_x17.Text = "X17  上料Z轴夹爪右夹紧";
            // 
            // lbl_x16
            // 
            this.lbl_x16.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x16.AutoSize = true;
            this.lbl_x16.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x16.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x16.ForeColor = System.Drawing.Color.Black;
            this.lbl_x16.Location = new System.Drawing.Point(230, 213);
            this.lbl_x16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x16.Name = "lbl_x16";
            this.lbl_x16.Size = new System.Drawing.Size(145, 18);
            this.lbl_x16.TabIndex = 79;
            this.lbl_x16.Text = "X16  上料Z轴夹爪右夹紧";
            // 
            // lbl_x15
            // 
            this.lbl_x15.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x15.AutoSize = true;
            this.lbl_x15.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x15.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x15.ForeColor = System.Drawing.Color.Black;
            this.lbl_x15.Location = new System.Drawing.Point(230, 182);
            this.lbl_x15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x15.Name = "lbl_x15";
            this.lbl_x15.Size = new System.Drawing.Size(145, 18);
            this.lbl_x15.TabIndex = 78;
            this.lbl_x15.Text = "X15  上料Z轴夹爪左夹紧";
            // 
            // lbl_x14
            // 
            this.lbl_x14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x14.AutoSize = true;
            this.lbl_x14.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x14.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x14.ForeColor = System.Drawing.Color.Black;
            this.lbl_x14.Location = new System.Drawing.Point(230, 150);
            this.lbl_x14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x14.Name = "lbl_x14";
            this.lbl_x14.Size = new System.Drawing.Size(145, 18);
            this.lbl_x14.TabIndex = 77;
            this.lbl_x14.Text = "X14  上料Z轴夹爪左夹紧";
            // 
            // lbl_x13
            // 
            this.lbl_x13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x13.AutoSize = true;
            this.lbl_x13.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x13.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x13.ForeColor = System.Drawing.Color.Black;
            this.lbl_x13.Location = new System.Drawing.Point(230, 118);
            this.lbl_x13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x13.Name = "lbl_x13";
            this.lbl_x13.Size = new System.Drawing.Size(132, 18);
            this.lbl_x13.TabIndex = 76;
            this.lbl_x13.Text = "X13  上料Z轴下气缸缩";
            // 
            // lbl_x12
            // 
            this.lbl_x12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x12.AutoSize = true;
            this.lbl_x12.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x12.ForeColor = System.Drawing.Color.Black;
            this.lbl_x12.Location = new System.Drawing.Point(230, 86);
            this.lbl_x12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x12.Name = "lbl_x12";
            this.lbl_x12.Size = new System.Drawing.Size(132, 18);
            this.lbl_x12.TabIndex = 75;
            this.lbl_x12.Text = "X12  上料Z轴下气缸伸";
            // 
            // lbl_x7
            // 
            this.lbl_x7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x7.AutoSize = true;
            this.lbl_x7.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x7.ForeColor = System.Drawing.Color.Black;
            this.lbl_x7.Location = new System.Drawing.Point(40, 244);
            this.lbl_x7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x7.Name = "lbl_x7";
            this.lbl_x7.Size = new System.Drawing.Size(23, 18);
            this.lbl_x7.TabIndex = 74;
            this.lbl_x7.Text = "X7";
            // 
            // lbl_x6
            // 
            this.lbl_x6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x6.AutoSize = true;
            this.lbl_x6.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x6.ForeColor = System.Drawing.Color.Black;
            this.lbl_x6.Location = new System.Drawing.Point(40, 213);
            this.lbl_x6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x6.Name = "lbl_x6";
            this.lbl_x6.Size = new System.Drawing.Size(23, 18);
            this.lbl_x6.TabIndex = 73;
            this.lbl_x6.Text = "X6";
            // 
            // lbl_x5
            // 
            this.lbl_x5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x5.AutoSize = true;
            this.lbl_x5.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x5.ForeColor = System.Drawing.Color.Black;
            this.lbl_x5.Location = new System.Drawing.Point(40, 182);
            this.lbl_x5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x5.Name = "lbl_x5";
            this.lbl_x5.Size = new System.Drawing.Size(41, 18);
            this.lbl_x5.TabIndex = 72;
            this.lbl_x5.Text = "X5 X-";
            // 
            // lbl_x4
            // 
            this.lbl_x4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x4.AutoSize = true;
            this.lbl_x4.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x4.ForeColor = System.Drawing.Color.Black;
            this.lbl_x4.Location = new System.Drawing.Point(40, 150);
            this.lbl_x4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x4.Name = "lbl_x4";
            this.lbl_x4.Size = new System.Drawing.Size(45, 18);
            this.lbl_x4.TabIndex = 71;
            this.lbl_x4.Text = "X4 X+";
            // 
            // lbl_x3
            // 
            this.lbl_x3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x3.AutoSize = true;
            this.lbl_x3.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x3.ForeColor = System.Drawing.Color.Black;
            this.lbl_x3.Location = new System.Drawing.Point(40, 118);
            this.lbl_x3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x3.Name = "lbl_x3";
            this.lbl_x3.Size = new System.Drawing.Size(23, 18);
            this.lbl_x3.TabIndex = 70;
            this.lbl_x3.Text = "X3";
            // 
            // lbl_x2
            // 
            this.lbl_x2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x2.AutoSize = true;
            this.lbl_x2.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x2.ForeColor = System.Drawing.Color.Black;
            this.lbl_x2.Location = new System.Drawing.Point(40, 86);
            this.lbl_x2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x2.Name = "lbl_x2";
            this.lbl_x2.Size = new System.Drawing.Size(23, 18);
            this.lbl_x2.TabIndex = 69;
            this.lbl_x2.Text = "X2";
            // 
            // lbl_x1
            // 
            this.lbl_x1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x1.AutoSize = true;
            this.lbl_x1.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x1.ForeColor = System.Drawing.Color.Black;
            this.lbl_x1.Location = new System.Drawing.Point(40, 54);
            this.lbl_x1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x1.Name = "lbl_x1";
            this.lbl_x1.Size = new System.Drawing.Size(23, 18);
            this.lbl_x1.TabIndex = 68;
            this.lbl_x1.Text = "X1";
            // 
            // lbl_x11
            // 
            this.lbl_x11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x11.AutoSize = true;
            this.lbl_x11.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x11.ForeColor = System.Drawing.Color.Black;
            this.lbl_x11.Location = new System.Drawing.Point(230, 54);
            this.lbl_x11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x11.Name = "lbl_x11";
            this.lbl_x11.Size = new System.Drawing.Size(132, 18);
            this.lbl_x11.TabIndex = 67;
            this.lbl_x11.Text = "X11  上料Z轴上气缸缩";
            // 
            // lbl_x10
            // 
            this.lbl_x10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x10.AutoSize = true;
            this.lbl_x10.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x10.ForeColor = System.Drawing.Color.Black;
            this.lbl_x10.Location = new System.Drawing.Point(230, 22);
            this.lbl_x10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x10.Name = "lbl_x10";
            this.lbl_x10.Size = new System.Drawing.Size(132, 18);
            this.lbl_x10.TabIndex = 66;
            this.lbl_x10.Text = "X10  上料Z轴上气缸伸";
            // 
            // lbl_x0
            // 
            this.lbl_x0.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_x0.AutoSize = true;
            this.lbl_x0.BackColor = System.Drawing.Color.Transparent;
            this.lbl_x0.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_x0.ForeColor = System.Drawing.Color.Black;
            this.lbl_x0.Location = new System.Drawing.Point(40, 22);
            this.lbl_x0.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_x0.Name = "lbl_x0";
            this.lbl_x0.Size = new System.Drawing.Size(30, 18);
            this.lbl_x0.TabIndex = 65;
            this.lbl_x0.Text = "X0 ";
            // 
            // tabItem1
            // 
            this.tabItem1.AttachedControl = this.tabControlPanel1;
            this.tabItem1.Name = "tabItem1";
            this.tabItem1.Text = "IO信号(X)";
            // 
            // tabControlPanel2
            // 
            this.tabControlPanel2.Controls.Add(this.uLan_y46);
            this.tabControlPanel2.Controls.Add(this.uLan_y42);
            this.tabControlPanel2.Controls.Add(this.uLan_y43);
            this.tabControlPanel2.Controls.Add(this.uLan_y45);
            this.tabControlPanel2.Controls.Add(this.userLantern100);
            this.tabControlPanel2.Controls.Add(this.uLan_y44);
            this.tabControlPanel2.Controls.Add(this.uLan_y41);
            this.tabControlPanel2.Controls.Add(this.uLan_y40);
            this.tabControlPanel2.Controls.Add(this.uLan_y47);
            this.tabControlPanel2.Controls.Add(this.uLan_y2);
            this.tabControlPanel2.Controls.Add(this.uLan_y3);
            this.tabControlPanel2.Controls.Add(this.uLan_y5);
            this.tabControlPanel2.Controls.Add(this.uLan_y6);
            this.tabControlPanel2.Controls.Add(this.uLan_y4);
            this.tabControlPanel2.Controls.Add(this.uLan_y1);
            this.tabControlPanel2.Controls.Add(this.uLan_y0);
            this.tabControlPanel2.Controls.Add(this.uLan_y7);
            this.tabControlPanel2.Controls.Add(this.uLan_y32);
            this.tabControlPanel2.Controls.Add(this.uLan_y33);
            this.tabControlPanel2.Controls.Add(this.uLan_y35);
            this.tabControlPanel2.Controls.Add(this.uLan_y36);
            this.tabControlPanel2.Controls.Add(this.uLan_y34);
            this.tabControlPanel2.Controls.Add(this.uLan_y31);
            this.tabControlPanel2.Controls.Add(this.uLan_y30);
            this.tabControlPanel2.Controls.Add(this.uLan_y37);
            this.tabControlPanel2.Controls.Add(this.uLan_y22);
            this.tabControlPanel2.Controls.Add(this.uLan_y23);
            this.tabControlPanel2.Controls.Add(this.uLan_y25);
            this.tabControlPanel2.Controls.Add(this.uLan_y26);
            this.tabControlPanel2.Controls.Add(this.uLan_y24);
            this.tabControlPanel2.Controls.Add(this.uLan_y21);
            this.tabControlPanel2.Controls.Add(this.uLan_y20);
            this.tabControlPanel2.Controls.Add(this.uLan_y27);
            this.tabControlPanel2.Controls.Add(this.uLan_y12);
            this.tabControlPanel2.Controls.Add(this.uLan_y13);
            this.tabControlPanel2.Controls.Add(this.uLan_y15);
            this.tabControlPanel2.Controls.Add(this.uLan_y16);
            this.tabControlPanel2.Controls.Add(this.uLan_y14);
            this.tabControlPanel2.Controls.Add(this.uLan_y11);
            this.tabControlPanel2.Controls.Add(this.uLan_y10);
            this.tabControlPanel2.Controls.Add(this.uLan_y17);
            this.tabControlPanel2.Controls.Add(this.lbl_y47);
            this.tabControlPanel2.Controls.Add(this.lbl_y46);
            this.tabControlPanel2.Controls.Add(this.lbl_y45);
            this.tabControlPanel2.Controls.Add(this.lbl_y44);
            this.tabControlPanel2.Controls.Add(this.lbl_y43);
            this.tabControlPanel2.Controls.Add(this.lbl_y42);
            this.tabControlPanel2.Controls.Add(this.lbl_y41);
            this.tabControlPanel2.Controls.Add(this.lbl_y40);
            this.tabControlPanel2.Controls.Add(this.lbl_y37);
            this.tabControlPanel2.Controls.Add(this.lbl_y36);
            this.tabControlPanel2.Controls.Add(this.lbl_y35);
            this.tabControlPanel2.Controls.Add(this.lbl_y34);
            this.tabControlPanel2.Controls.Add(this.lbl_y33);
            this.tabControlPanel2.Controls.Add(this.lbl_y32);
            this.tabControlPanel2.Controls.Add(this.lbl_y31);
            this.tabControlPanel2.Controls.Add(this.lbl_y27);
            this.tabControlPanel2.Controls.Add(this.lbl_y25);
            this.tabControlPanel2.Controls.Add(this.lbl_y30);
            this.tabControlPanel2.Controls.Add(this.lbl_y26);
            this.tabControlPanel2.Controls.Add(this.lbl_y24);
            this.tabControlPanel2.Controls.Add(this.lbl_y23);
            this.tabControlPanel2.Controls.Add(this.lbl_y22);
            this.tabControlPanel2.Controls.Add(this.lbl_y21);
            this.tabControlPanel2.Controls.Add(this.lbl_y20);
            this.tabControlPanel2.Controls.Add(this.lbl_y17);
            this.tabControlPanel2.Controls.Add(this.lbl_y16);
            this.tabControlPanel2.Controls.Add(this.lbl_y15);
            this.tabControlPanel2.Controls.Add(this.lbl_y14);
            this.tabControlPanel2.Controls.Add(this.lbl_y13);
            this.tabControlPanel2.Controls.Add(this.lbl_y12);
            this.tabControlPanel2.Controls.Add(this.lbl_y7);
            this.tabControlPanel2.Controls.Add(this.lbl_y6);
            this.tabControlPanel2.Controls.Add(this.lbl_y5);
            this.tabControlPanel2.Controls.Add(this.lbl_y4);
            this.tabControlPanel2.Controls.Add(this.lbl_y3);
            this.tabControlPanel2.Controls.Add(this.lbl_y2);
            this.tabControlPanel2.Controls.Add(this.lbl_y1);
            this.tabControlPanel2.Controls.Add(this.lbl_y11);
            this.tabControlPanel2.Controls.Add(this.lbl_y10);
            this.tabControlPanel2.Controls.Add(this.lbl_y0);
            this.tabControlPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel2.Location = new System.Drawing.Point(0, 28);
            this.tabControlPanel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabControlPanel2.Name = "tabControlPanel2";
            this.tabControlPanel2.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel2.Size = new System.Drawing.Size(817, 617);
            this.tabControlPanel2.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(179)))), ((int)(((byte)(231)))));
            this.tabControlPanel2.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(237)))), ((int)(((byte)(254)))));
            this.tabControlPanel2.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel2.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(97)))), ((int)(((byte)(156)))));
            this.tabControlPanel2.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right) 
            | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel2.Style.GradientAngle = 90;
            this.tabControlPanel2.TabIndex = 2;
            this.tabControlPanel2.TabItem = this.tabItem2;
            // 
            // uLan_y46
            // 
            this.uLan_y46.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y46.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y46.Location = new System.Drawing.Point(15, 506);
            this.uLan_y46.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.uLan_y46.Name = "uLan_y46";
            this.uLan_y46.Size = new System.Drawing.Size(26, 23);
            this.uLan_y46.TabIndex = 214;
            // 
            // uLan_y42
            // 
            this.uLan_y42.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y42.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y42.Location = new System.Drawing.Point(12, 379);
            this.uLan_y42.Margin = new System.Windows.Forms.Padding(14, 38, 14, 38);
            this.uLan_y42.Name = "uLan_y42";
            this.uLan_y42.Size = new System.Drawing.Size(26, 23);
            this.uLan_y42.TabIndex = 213;
            // 
            // uLan_y43
            // 
            this.uLan_y43.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y43.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y43.Location = new System.Drawing.Point(12, 411);
            this.uLan_y43.Margin = new System.Windows.Forms.Padding(14, 38, 14, 38);
            this.uLan_y43.Name = "uLan_y43";
            this.uLan_y43.Size = new System.Drawing.Size(26, 23);
            this.uLan_y43.TabIndex = 212;
            // 
            // uLan_y45
            // 
            this.uLan_y45.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y45.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y45.Location = new System.Drawing.Point(12, 475);
            this.uLan_y45.Margin = new System.Windows.Forms.Padding(14, 38, 14, 38);
            this.uLan_y45.Name = "uLan_y45";
            this.uLan_y45.Size = new System.Drawing.Size(26, 23);
            this.uLan_y45.TabIndex = 211;
            // 
            // userLantern100
            // 
            this.userLantern100.BackColor = System.Drawing.Color.Transparent;
            this.userLantern100.LanternBackground = System.Drawing.Color.Gray;
            this.userLantern100.Location = new System.Drawing.Point(15, 642);
            this.userLantern100.Margin = new System.Windows.Forms.Padding(18, 48, 18, 48);
            this.userLantern100.Name = "userLantern100";
            this.userLantern100.Size = new System.Drawing.Size(33, 30);
            this.userLantern100.TabIndex = 210;
            // 
            // uLan_y44
            // 
            this.uLan_y44.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y44.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y44.Location = new System.Drawing.Point(12, 443);
            this.uLan_y44.Margin = new System.Windows.Forms.Padding(14, 38, 14, 38);
            this.uLan_y44.Name = "uLan_y44";
            this.uLan_y44.Size = new System.Drawing.Size(26, 23);
            this.uLan_y44.TabIndex = 209;
            // 
            // uLan_y41
            // 
            this.uLan_y41.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y41.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y41.Location = new System.Drawing.Point(12, 347);
            this.uLan_y41.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y41.Name = "uLan_y41";
            this.uLan_y41.Size = new System.Drawing.Size(26, 23);
            this.uLan_y41.TabIndex = 208;
            // 
            // uLan_y40
            // 
            this.uLan_y40.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y40.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y40.Location = new System.Drawing.Point(12, 315);
            this.uLan_y40.Margin = new System.Windows.Forms.Padding(9, 23, 9, 23);
            this.uLan_y40.Name = "uLan_y40";
            this.uLan_y40.Size = new System.Drawing.Size(26, 23);
            this.uLan_y40.TabIndex = 207;
            // 
            // uLan_y47
            // 
            this.uLan_y47.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y47.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y47.Location = new System.Drawing.Point(12, 539);
            this.uLan_y47.Margin = new System.Windows.Forms.Padding(8, 18, 8, 18);
            this.uLan_y47.Name = "uLan_y47";
            this.uLan_y47.Size = new System.Drawing.Size(26, 23);
            this.uLan_y47.TabIndex = 206;
            // 
            // uLan_y2
            // 
            this.uLan_y2.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y2.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y2.Location = new System.Drawing.Point(10, 92);
            this.uLan_y2.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y2.Name = "uLan_y2";
            this.uLan_y2.Size = new System.Drawing.Size(26, 23);
            this.uLan_y2.TabIndex = 205;
            // 
            // uLan_y3
            // 
            this.uLan_y3.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y3.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y3.Location = new System.Drawing.Point(10, 122);
            this.uLan_y3.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y3.Name = "uLan_y3";
            this.uLan_y3.Size = new System.Drawing.Size(26, 23);
            this.uLan_y3.TabIndex = 204;
            // 
            // uLan_y5
            // 
            this.uLan_y5.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y5.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y5.Location = new System.Drawing.Point(10, 183);
            this.uLan_y5.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y5.Name = "uLan_y5";
            this.uLan_y5.Size = new System.Drawing.Size(26, 23);
            this.uLan_y5.TabIndex = 203;
            // 
            // uLan_y6
            // 
            this.uLan_y6.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y6.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y6.Location = new System.Drawing.Point(10, 214);
            this.uLan_y6.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y6.Name = "uLan_y6";
            this.uLan_y6.Size = new System.Drawing.Size(26, 23);
            this.uLan_y6.TabIndex = 202;
            // 
            // uLan_y4
            // 
            this.uLan_y4.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y4.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y4.Location = new System.Drawing.Point(10, 153);
            this.uLan_y4.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y4.Name = "uLan_y4";
            this.uLan_y4.Size = new System.Drawing.Size(26, 23);
            this.uLan_y4.TabIndex = 201;
            // 
            // uLan_y1
            // 
            this.uLan_y1.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y1.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y1.Location = new System.Drawing.Point(10, 62);
            this.uLan_y1.Margin = new System.Windows.Forms.Padding(9, 23, 9, 23);
            this.uLan_y1.Name = "uLan_y1";
            this.uLan_y1.Size = new System.Drawing.Size(26, 23);
            this.uLan_y1.TabIndex = 200;
            // 
            // uLan_y0
            // 
            this.uLan_y0.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y0.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y0.Location = new System.Drawing.Point(10, 31);
            this.uLan_y0.Margin = new System.Windows.Forms.Padding(8, 18, 8, 18);
            this.uLan_y0.Name = "uLan_y0";
            this.uLan_y0.Size = new System.Drawing.Size(26, 23);
            this.uLan_y0.TabIndex = 199;
            // 
            // uLan_y7
            // 
            this.uLan_y7.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y7.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y7.Location = new System.Drawing.Point(10, 244);
            this.uLan_y7.Margin = new System.Windows.Forms.Padding(6, 14, 6, 14);
            this.uLan_y7.Name = "uLan_y7";
            this.uLan_y7.Size = new System.Drawing.Size(26, 23);
            this.uLan_y7.TabIndex = 198;
            // 
            // uLan_y32
            // 
            this.uLan_y32.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y32.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y32.Location = new System.Drawing.Point(576, 92);
            this.uLan_y32.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y32.Name = "uLan_y32";
            this.uLan_y32.Size = new System.Drawing.Size(26, 23);
            this.uLan_y32.TabIndex = 197;
            // 
            // uLan_y33
            // 
            this.uLan_y33.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y33.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y33.Location = new System.Drawing.Point(576, 122);
            this.uLan_y33.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y33.Name = "uLan_y33";
            this.uLan_y33.Size = new System.Drawing.Size(26, 23);
            this.uLan_y33.TabIndex = 196;
            // 
            // uLan_y35
            // 
            this.uLan_y35.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y35.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y35.Location = new System.Drawing.Point(576, 183);
            this.uLan_y35.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y35.Name = "uLan_y35";
            this.uLan_y35.Size = new System.Drawing.Size(26, 23);
            this.uLan_y35.TabIndex = 195;
            // 
            // uLan_y36
            // 
            this.uLan_y36.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y36.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y36.Location = new System.Drawing.Point(576, 214);
            this.uLan_y36.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y36.Name = "uLan_y36";
            this.uLan_y36.Size = new System.Drawing.Size(26, 23);
            this.uLan_y36.TabIndex = 194;
            // 
            // uLan_y34
            // 
            this.uLan_y34.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y34.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y34.Location = new System.Drawing.Point(576, 153);
            this.uLan_y34.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y34.Name = "uLan_y34";
            this.uLan_y34.Size = new System.Drawing.Size(26, 23);
            this.uLan_y34.TabIndex = 193;
            // 
            // uLan_y31
            // 
            this.uLan_y31.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y31.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y31.Location = new System.Drawing.Point(576, 62);
            this.uLan_y31.Margin = new System.Windows.Forms.Padding(9, 23, 9, 23);
            this.uLan_y31.Name = "uLan_y31";
            this.uLan_y31.Size = new System.Drawing.Size(26, 23);
            this.uLan_y31.TabIndex = 192;
            // 
            // uLan_y30
            // 
            this.uLan_y30.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y30.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y30.Location = new System.Drawing.Point(576, 31);
            this.uLan_y30.Margin = new System.Windows.Forms.Padding(8, 18, 8, 18);
            this.uLan_y30.Name = "uLan_y30";
            this.uLan_y30.Size = new System.Drawing.Size(26, 23);
            this.uLan_y30.TabIndex = 191;
            // 
            // uLan_y37
            // 
            this.uLan_y37.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y37.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y37.Location = new System.Drawing.Point(576, 244);
            this.uLan_y37.Margin = new System.Windows.Forms.Padding(6, 14, 6, 14);
            this.uLan_y37.Name = "uLan_y37";
            this.uLan_y37.Size = new System.Drawing.Size(26, 23);
            this.uLan_y37.TabIndex = 190;
            // 
            // uLan_y22
            // 
            this.uLan_y22.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y22.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y22.Location = new System.Drawing.Point(381, 92);
            this.uLan_y22.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y22.Name = "uLan_y22";
            this.uLan_y22.Size = new System.Drawing.Size(26, 23);
            this.uLan_y22.TabIndex = 189;
            // 
            // uLan_y23
            // 
            this.uLan_y23.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y23.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y23.Location = new System.Drawing.Point(381, 122);
            this.uLan_y23.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y23.Name = "uLan_y23";
            this.uLan_y23.Size = new System.Drawing.Size(26, 23);
            this.uLan_y23.TabIndex = 188;
            // 
            // uLan_y25
            // 
            this.uLan_y25.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y25.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y25.Location = new System.Drawing.Point(381, 183);
            this.uLan_y25.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y25.Name = "uLan_y25";
            this.uLan_y25.Size = new System.Drawing.Size(26, 23);
            this.uLan_y25.TabIndex = 187;
            // 
            // uLan_y26
            // 
            this.uLan_y26.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y26.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y26.Location = new System.Drawing.Point(381, 214);
            this.uLan_y26.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y26.Name = "uLan_y26";
            this.uLan_y26.Size = new System.Drawing.Size(26, 23);
            this.uLan_y26.TabIndex = 186;
            // 
            // uLan_y24
            // 
            this.uLan_y24.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y24.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y24.Location = new System.Drawing.Point(381, 153);
            this.uLan_y24.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y24.Name = "uLan_y24";
            this.uLan_y24.Size = new System.Drawing.Size(26, 23);
            this.uLan_y24.TabIndex = 185;
            // 
            // uLan_y21
            // 
            this.uLan_y21.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y21.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y21.Location = new System.Drawing.Point(381, 62);
            this.uLan_y21.Margin = new System.Windows.Forms.Padding(9, 23, 9, 23);
            this.uLan_y21.Name = "uLan_y21";
            this.uLan_y21.Size = new System.Drawing.Size(26, 23);
            this.uLan_y21.TabIndex = 184;
            // 
            // uLan_y20
            // 
            this.uLan_y20.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y20.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y20.Location = new System.Drawing.Point(381, 31);
            this.uLan_y20.Margin = new System.Windows.Forms.Padding(8, 18, 8, 18);
            this.uLan_y20.Name = "uLan_y20";
            this.uLan_y20.Size = new System.Drawing.Size(26, 23);
            this.uLan_y20.TabIndex = 183;
            // 
            // uLan_y27
            // 
            this.uLan_y27.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y27.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y27.Location = new System.Drawing.Point(381, 244);
            this.uLan_y27.Margin = new System.Windows.Forms.Padding(6, 14, 6, 14);
            this.uLan_y27.Name = "uLan_y27";
            this.uLan_y27.Size = new System.Drawing.Size(26, 23);
            this.uLan_y27.TabIndex = 182;
            // 
            // uLan_y12
            // 
            this.uLan_y12.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y12.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y12.Location = new System.Drawing.Point(180, 92);
            this.uLan_y12.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y12.Name = "uLan_y12";
            this.uLan_y12.Size = new System.Drawing.Size(26, 23);
            this.uLan_y12.TabIndex = 181;
            // 
            // uLan_y13
            // 
            this.uLan_y13.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y13.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y13.Location = new System.Drawing.Point(180, 122);
            this.uLan_y13.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y13.Name = "uLan_y13";
            this.uLan_y13.Size = new System.Drawing.Size(26, 23);
            this.uLan_y13.TabIndex = 180;
            // 
            // uLan_y15
            // 
            this.uLan_y15.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y15.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y15.Location = new System.Drawing.Point(180, 183);
            this.uLan_y15.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y15.Name = "uLan_y15";
            this.uLan_y15.Size = new System.Drawing.Size(26, 23);
            this.uLan_y15.TabIndex = 179;
            // 
            // uLan_y16
            // 
            this.uLan_y16.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y16.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y16.Location = new System.Drawing.Point(180, 214);
            this.uLan_y16.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y16.Name = "uLan_y16";
            this.uLan_y16.Size = new System.Drawing.Size(26, 23);
            this.uLan_y16.TabIndex = 178;
            // 
            // uLan_y14
            // 
            this.uLan_y14.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y14.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y14.Location = new System.Drawing.Point(180, 153);
            this.uLan_y14.Margin = new System.Windows.Forms.Padding(11, 30, 11, 30);
            this.uLan_y14.Name = "uLan_y14";
            this.uLan_y14.Size = new System.Drawing.Size(26, 23);
            this.uLan_y14.TabIndex = 177;
            // 
            // uLan_y11
            // 
            this.uLan_y11.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y11.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y11.Location = new System.Drawing.Point(180, 62);
            this.uLan_y11.Margin = new System.Windows.Forms.Padding(9, 23, 9, 23);
            this.uLan_y11.Name = "uLan_y11";
            this.uLan_y11.Size = new System.Drawing.Size(26, 23);
            this.uLan_y11.TabIndex = 176;
            // 
            // uLan_y10
            // 
            this.uLan_y10.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y10.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y10.Location = new System.Drawing.Point(180, 31);
            this.uLan_y10.Margin = new System.Windows.Forms.Padding(8, 18, 8, 18);
            this.uLan_y10.Name = "uLan_y10";
            this.uLan_y10.Size = new System.Drawing.Size(26, 23);
            this.uLan_y10.TabIndex = 175;
            // 
            // uLan_y17
            // 
            this.uLan_y17.BackColor = System.Drawing.Color.Transparent;
            this.uLan_y17.LanternBackground = System.Drawing.Color.Gray;
            this.uLan_y17.Location = new System.Drawing.Point(180, 244);
            this.uLan_y17.Margin = new System.Windows.Forms.Padding(6, 14, 6, 14);
            this.uLan_y17.Name = "uLan_y17";
            this.uLan_y17.Size = new System.Drawing.Size(26, 23);
            this.uLan_y17.TabIndex = 174;
            // 
            // lbl_y47
            // 
            this.lbl_y47.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y47.AutoSize = true;
            this.lbl_y47.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y47.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y47.ForeColor = System.Drawing.Color.White;
            this.lbl_y47.Location = new System.Drawing.Point(38, 543);
            this.lbl_y47.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y47.Name = "lbl_y47";
            this.lbl_y47.Size = new System.Drawing.Size(30, 18);
            this.lbl_y47.TabIndex = 168;
            this.lbl_y47.Text = "Y47";
            // 
            // lbl_y46
            // 
            this.lbl_y46.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y46.AutoSize = true;
            this.lbl_y46.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y46.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y46.ForeColor = System.Drawing.Color.Black;
            this.lbl_y46.Location = new System.Drawing.Point(38, 511);
            this.lbl_y46.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y46.Name = "lbl_y46";
            this.lbl_y46.Size = new System.Drawing.Size(30, 18);
            this.lbl_y46.TabIndex = 167;
            this.lbl_y46.Text = "Y46";
            // 
            // lbl_y45
            // 
            this.lbl_y45.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y45.AutoSize = true;
            this.lbl_y45.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y45.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y45.ForeColor = System.Drawing.Color.Black;
            this.lbl_y45.Location = new System.Drawing.Point(38, 479);
            this.lbl_y45.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y45.Name = "lbl_y45";
            this.lbl_y45.Size = new System.Drawing.Size(30, 18);
            this.lbl_y45.TabIndex = 166;
            this.lbl_y45.Text = "Y45";
            // 
            // lbl_y44
            // 
            this.lbl_y44.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y44.AutoSize = true;
            this.lbl_y44.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y44.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y44.ForeColor = System.Drawing.Color.Black;
            this.lbl_y44.Location = new System.Drawing.Point(38, 447);
            this.lbl_y44.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y44.Name = "lbl_y44";
            this.lbl_y44.Size = new System.Drawing.Size(74, 18);
            this.lbl_y44.TabIndex = 165;
            this.lbl_y44.Text = "Y44  蜂鸣器";
            // 
            // lbl_y43
            // 
            this.lbl_y43.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y43.AutoSize = true;
            this.lbl_y43.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y43.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y43.ForeColor = System.Drawing.Color.Black;
            this.lbl_y43.Location = new System.Drawing.Point(38, 415);
            this.lbl_y43.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y43.Name = "lbl_y43";
            this.lbl_y43.Size = new System.Drawing.Size(99, 18);
            this.lbl_y43.TabIndex = 164;
            this.lbl_y43.Text = "Y43  驱动器使能";
            // 
            // lbl_y42
            // 
            this.lbl_y42.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y42.AutoSize = true;
            this.lbl_y42.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y42.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y42.ForeColor = System.Drawing.Color.Black;
            this.lbl_y42.Location = new System.Drawing.Point(38, 383);
            this.lbl_y42.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y42.Name = "lbl_y42";
            this.lbl_y42.Size = new System.Drawing.Size(85, 18);
            this.lbl_y42.TabIndex = 163;
            this.lbl_y42.Text = "Y42  Y_Reset";
            // 
            // lbl_y41
            // 
            this.lbl_y41.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y41.AutoSize = true;
            this.lbl_y41.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y41.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y41.ForeColor = System.Drawing.Color.Black;
            this.lbl_y41.Location = new System.Drawing.Point(38, 351);
            this.lbl_y41.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y41.Name = "lbl_y41";
            this.lbl_y41.Size = new System.Drawing.Size(86, 18);
            this.lbl_y41.TabIndex = 162;
            this.lbl_y41.Text = "Y41  X_Reset";
            // 
            // lbl_y40
            // 
            this.lbl_y40.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y40.AutoSize = true;
            this.lbl_y40.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y40.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y40.ForeColor = System.Drawing.Color.Black;
            this.lbl_y40.Location = new System.Drawing.Point(38, 319);
            this.lbl_y40.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y40.Name = "lbl_y40";
            this.lbl_y40.Size = new System.Drawing.Size(124, 18);
            this.lbl_y40.TabIndex = 161;
            this.lbl_y40.Text = "Y40  整体移位气缸缩";
            // 
            // lbl_y37
            // 
            this.lbl_y37.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y37.AutoSize = true;
            this.lbl_y37.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y37.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y37.ForeColor = System.Drawing.Color.Black;
            this.lbl_y37.Location = new System.Drawing.Point(604, 249);
            this.lbl_y37.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y37.Name = "lbl_y37";
            this.lbl_y37.Size = new System.Drawing.Size(124, 18);
            this.lbl_y37.TabIndex = 160;
            this.lbl_y37.Text = "Y37  整体移位气缸伸";
            // 
            // lbl_y36
            // 
            this.lbl_y36.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y36.AutoSize = true;
            this.lbl_y36.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y36.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y36.ForeColor = System.Drawing.Color.Black;
            this.lbl_y36.Location = new System.Drawing.Point(604, 215);
            this.lbl_y36.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y36.Name = "lbl_y36";
            this.lbl_y36.Size = new System.Drawing.Size(111, 18);
            this.lbl_y36.TabIndex = 159;
            this.lbl_y36.Text = "Y36  整体移位气缸";
            // 
            // lbl_y35
            // 
            this.lbl_y35.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y35.AutoSize = true;
            this.lbl_y35.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y35.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y35.ForeColor = System.Drawing.Color.Black;
            this.lbl_y35.Location = new System.Drawing.Point(604, 185);
            this.lbl_y35.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y35.Name = "lbl_y35";
            this.lbl_y35.Size = new System.Drawing.Size(136, 18);
            this.lbl_y35.TabIndex = 158;
            this.lbl_y35.Text = "Y35  下料整体下料气缸";
            // 
            // lbl_y34
            // 
            this.lbl_y34.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y34.AutoSize = true;
            this.lbl_y34.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y34.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y34.ForeColor = System.Drawing.Color.Black;
            this.lbl_y34.Location = new System.Drawing.Point(604, 155);
            this.lbl_y34.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y34.Name = "lbl_y34";
            this.lbl_y34.Size = new System.Drawing.Size(111, 18);
            this.lbl_y34.TabIndex = 157;
            this.lbl_y34.Text = "Y34  下料定位气缸";
            // 
            // lbl_y33
            // 
            this.lbl_y33.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y33.AutoSize = true;
            this.lbl_y33.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y33.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y33.ForeColor = System.Drawing.Color.Black;
            this.lbl_y33.Location = new System.Drawing.Point(604, 125);
            this.lbl_y33.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y33.Name = "lbl_y33";
            this.lbl_y33.Size = new System.Drawing.Size(132, 18);
            this.lbl_y33.TabIndex = 156;
            this.lbl_y33.Text = "Y33  下料Z轴夹爪气缸";
            // 
            // lbl_y32
            // 
            this.lbl_y32.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y32.AutoSize = true;
            this.lbl_y32.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y32.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y32.ForeColor = System.Drawing.Color.Black;
            this.lbl_y32.Location = new System.Drawing.Point(604, 93);
            this.lbl_y32.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y32.Name = "lbl_y32";
            this.lbl_y32.Size = new System.Drawing.Size(119, 18);
            this.lbl_y32.TabIndex = 155;
            this.lbl_y32.Text = "Y32  下料Z轴气缸下";
            // 
            // lbl_y31
            // 
            this.lbl_y31.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y31.AutoSize = true;
            this.lbl_y31.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y31.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y31.ForeColor = System.Drawing.Color.Black;
            this.lbl_y31.Location = new System.Drawing.Point(604, 62);
            this.lbl_y31.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y31.Name = "lbl_y31";
            this.lbl_y31.Size = new System.Drawing.Size(119, 18);
            this.lbl_y31.TabIndex = 154;
            this.lbl_y31.Text = "Y31  下料Z轴气缸上";
            // 
            // lbl_y27
            // 
            this.lbl_y27.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y27.AutoSize = true;
            this.lbl_y27.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y27.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y27.ForeColor = System.Drawing.Color.Black;
            this.lbl_y27.Location = new System.Drawing.Point(410, 249);
            this.lbl_y27.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y27.Name = "lbl_y27";
            this.lbl_y27.Size = new System.Drawing.Size(131, 18);
            this.lbl_y27.TabIndex = 152;
            this.lbl_y27.Text = "Y27  NG分选旋转气缸";
            // 
            // lbl_y25
            // 
            this.lbl_y25.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y25.AutoSize = true;
            this.lbl_y25.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y25.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y25.ForeColor = System.Drawing.Color.Black;
            this.lbl_y25.Location = new System.Drawing.Point(410, 185);
            this.lbl_y25.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y25.Name = "lbl_y25";
            this.lbl_y25.Size = new System.Drawing.Size(131, 18);
            this.lbl_y25.TabIndex = 150;
            this.lbl_y25.Text = "Y25  NG分选移位气缸";
            // 
            // lbl_y30
            // 
            this.lbl_y30.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y30.AutoSize = true;
            this.lbl_y30.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y30.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y30.ForeColor = System.Drawing.Color.Black;
            this.lbl_y30.Location = new System.Drawing.Point(604, 33);
            this.lbl_y30.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y30.Name = "lbl_y30";
            this.lbl_y30.Size = new System.Drawing.Size(119, 18);
            this.lbl_y30.TabIndex = 153;
            this.lbl_y30.Text = "Y30  NG分选真空吸";
            // 
            // lbl_y26
            // 
            this.lbl_y26.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y26.AutoSize = true;
            this.lbl_y26.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y26.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y26.ForeColor = System.Drawing.Color.Black;
            this.lbl_y26.Location = new System.Drawing.Point(410, 215);
            this.lbl_y26.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y26.Name = "lbl_y26";
            this.lbl_y26.Size = new System.Drawing.Size(127, 18);
            this.lbl_y26.TabIndex = 151;
            this.lbl_y26.Text = "Y26  NG分选Z轴气缸";
            // 
            // lbl_y24
            // 
            this.lbl_y24.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y24.AutoSize = true;
            this.lbl_y24.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y24.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y24.ForeColor = System.Drawing.Color.Black;
            this.lbl_y24.Location = new System.Drawing.Point(410, 155);
            this.lbl_y24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y24.Name = "lbl_y24";
            this.lbl_y24.Size = new System.Drawing.Size(131, 18);
            this.lbl_y24.TabIndex = 149;
            this.lbl_y24.Text = "Y24  NG分选定位气缸";
            // 
            // lbl_y23
            // 
            this.lbl_y23.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y23.AutoSize = true;
            this.lbl_y23.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y23.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y23.ForeColor = System.Drawing.Color.Black;
            this.lbl_y23.Location = new System.Drawing.Point(410, 125);
            this.lbl_y23.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y23.Name = "lbl_y23";
            this.lbl_y23.Size = new System.Drawing.Size(114, 18);
            this.lbl_y23.TabIndex = 148;
            this.lbl_y23.Text = "Y23  OCV压合气缸";
            // 
            // lbl_y22
            // 
            this.lbl_y22.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y22.AutoSize = true;
            this.lbl_y22.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y22.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y22.ForeColor = System.Drawing.Color.Black;
            this.lbl_y22.Location = new System.Drawing.Point(410, 93);
            this.lbl_y22.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y22.Name = "lbl_y22";
            this.lbl_y22.Size = new System.Drawing.Size(114, 18);
            this.lbl_y22.TabIndex = 147;
            this.lbl_y22.Text = "Y22  OCV移位气缸";
            // 
            // lbl_y21
            // 
            this.lbl_y21.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y21.AutoSize = true;
            this.lbl_y21.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y21.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y21.ForeColor = System.Drawing.Color.Black;
            this.lbl_y21.Location = new System.Drawing.Point(410, 62);
            this.lbl_y21.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y21.Name = "lbl_y21";
            this.lbl_y21.Size = new System.Drawing.Size(114, 18);
            this.lbl_y21.TabIndex = 146;
            this.lbl_y21.Text = "Y21  OCV定位气缸";
            // 
            // lbl_y20
            // 
            this.lbl_y20.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y20.AutoSize = true;
            this.lbl_y20.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y20.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y20.ForeColor = System.Drawing.Color.Black;
            this.lbl_y20.Location = new System.Drawing.Point(410, 33);
            this.lbl_y20.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y20.Name = "lbl_y20";
            this.lbl_y20.Size = new System.Drawing.Size(124, 18);
            this.lbl_y20.TabIndex = 145;
            this.lbl_y20.Text = "Y20  上料允许指示灯";
            // 
            // lbl_y17
            // 
            this.lbl_y17.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y17.AutoSize = true;
            this.lbl_y17.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y17.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y17.ForeColor = System.Drawing.Color.Black;
            this.lbl_y17.Location = new System.Drawing.Point(203, 249);
            this.lbl_y17.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y17.Name = "lbl_y17";
            this.lbl_y17.Size = new System.Drawing.Size(124, 18);
            this.lbl_y17.TabIndex = 144;
            this.lbl_y17.Text = "Y17  上料到位指示灯";
            // 
            // lbl_y16
            // 
            this.lbl_y16.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y16.AutoSize = true;
            this.lbl_y16.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y16.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y16.ForeColor = System.Drawing.Color.Black;
            this.lbl_y16.Location = new System.Drawing.Point(203, 215);
            this.lbl_y16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y16.Name = "lbl_y16";
            this.lbl_y16.Size = new System.Drawing.Size(111, 18);
            this.lbl_y16.TabIndex = 143;
            this.lbl_y16.Text = "Y16  上料移位气缸";
            // 
            // lbl_y15
            // 
            this.lbl_y15.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y15.AutoSize = true;
            this.lbl_y15.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y15.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y15.ForeColor = System.Drawing.Color.Black;
            this.lbl_y15.Location = new System.Drawing.Point(203, 185);
            this.lbl_y15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y15.Name = "lbl_y15";
            this.lbl_y15.Size = new System.Drawing.Size(111, 18);
            this.lbl_y15.TabIndex = 142;
            this.lbl_y15.Text = "Y15  上料防呆气缸";
            // 
            // lbl_y14
            // 
            this.lbl_y14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y14.AutoSize = true;
            this.lbl_y14.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y14.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y14.ForeColor = System.Drawing.Color.Black;
            this.lbl_y14.Location = new System.Drawing.Point(203, 155);
            this.lbl_y14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y14.Name = "lbl_y14";
            this.lbl_y14.Size = new System.Drawing.Size(124, 18);
            this.lbl_y14.TabIndex = 141;
            this.lbl_y14.Text = "Y14  上料后定位气缸";
            // 
            // lbl_y13
            // 
            this.lbl_y13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y13.AutoSize = true;
            this.lbl_y13.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y13.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y13.ForeColor = System.Drawing.Color.Black;
            this.lbl_y13.Location = new System.Drawing.Point(203, 125);
            this.lbl_y13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y13.Name = "lbl_y13";
            this.lbl_y13.Size = new System.Drawing.Size(124, 18);
            this.lbl_y13.TabIndex = 140;
            this.lbl_y13.Text = "Y13  上料前定位气缸";
            // 
            // lbl_y12
            // 
            this.lbl_y12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y12.AutoSize = true;
            this.lbl_y12.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y12.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y12.ForeColor = System.Drawing.Color.Black;
            this.lbl_y12.Location = new System.Drawing.Point(203, 93);
            this.lbl_y12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y12.Name = "lbl_y12";
            this.lbl_y12.Size = new System.Drawing.Size(132, 18);
            this.lbl_y12.TabIndex = 139;
            this.lbl_y12.Text = "Y12  上料Z轴夹爪气缸";
            // 
            // lbl_y7
            // 
            this.lbl_y7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y7.AutoSize = true;
            this.lbl_y7.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y7.ForeColor = System.Drawing.Color.Black;
            this.lbl_y7.Location = new System.Drawing.Point(38, 249);
            this.lbl_y7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y7.Name = "lbl_y7";
            this.lbl_y7.Size = new System.Drawing.Size(22, 18);
            this.lbl_y7.TabIndex = 138;
            this.lbl_y7.Text = "Y7";
            // 
            // lbl_y6
            // 
            this.lbl_y6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y6.AutoSize = true;
            this.lbl_y6.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y6.ForeColor = System.Drawing.Color.Black;
            this.lbl_y6.Location = new System.Drawing.Point(38, 215);
            this.lbl_y6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y6.Name = "lbl_y6";
            this.lbl_y6.Size = new System.Drawing.Size(22, 18);
            this.lbl_y6.TabIndex = 137;
            this.lbl_y6.Text = "Y6";
            // 
            // lbl_y5
            // 
            this.lbl_y5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y5.AutoSize = true;
            this.lbl_y5.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y5.ForeColor = System.Drawing.Color.Black;
            this.lbl_y5.Location = new System.Drawing.Point(38, 185);
            this.lbl_y5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y5.Name = "lbl_y5";
            this.lbl_y5.Size = new System.Drawing.Size(66, 18);
            this.lbl_y5.TabIndex = 136;
            this.lbl_y5.Text = "Y5  X_DIR";
            // 
            // lbl_y4
            // 
            this.lbl_y4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y4.AutoSize = true;
            this.lbl_y4.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y4.ForeColor = System.Drawing.Color.Black;
            this.lbl_y4.Location = new System.Drawing.Point(38, 155);
            this.lbl_y4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y4.Name = "lbl_y4";
            this.lbl_y4.Size = new System.Drawing.Size(66, 18);
            this.lbl_y4.TabIndex = 135;
            this.lbl_y4.Text = "Y4  X_DIR";
            // 
            // lbl_y3
            // 
            this.lbl_y3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y3.AutoSize = true;
            this.lbl_y3.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y3.ForeColor = System.Drawing.Color.Black;
            this.lbl_y3.Location = new System.Drawing.Point(38, 125);
            this.lbl_y3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y3.Name = "lbl_y3";
            this.lbl_y3.Size = new System.Drawing.Size(22, 18);
            this.lbl_y3.TabIndex = 134;
            this.lbl_y3.Text = "Y3";
            // 
            // lbl_y2
            // 
            this.lbl_y2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y2.AutoSize = true;
            this.lbl_y2.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y2.ForeColor = System.Drawing.Color.Black;
            this.lbl_y2.Location = new System.Drawing.Point(38, 93);
            this.lbl_y2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y2.Name = "lbl_y2";
            this.lbl_y2.Size = new System.Drawing.Size(22, 18);
            this.lbl_y2.TabIndex = 133;
            this.lbl_y2.Text = "Y2";
            // 
            // lbl_y1
            // 
            this.lbl_y1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y1.AutoSize = true;
            this.lbl_y1.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y1.ForeColor = System.Drawing.Color.Black;
            this.lbl_y1.Location = new System.Drawing.Point(38, 62);
            this.lbl_y1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y1.Name = "lbl_y1";
            this.lbl_y1.Size = new System.Drawing.Size(68, 18);
            this.lbl_y1.TabIndex = 132;
            this.lbl_y1.Text = "Y1  Y_PLU";
            // 
            // lbl_y11
            // 
            this.lbl_y11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y11.AutoSize = true;
            this.lbl_y11.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y11.ForeColor = System.Drawing.Color.Black;
            this.lbl_y11.Location = new System.Drawing.Point(203, 62);
            this.lbl_y11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y11.Name = "lbl_y11";
            this.lbl_y11.Size = new System.Drawing.Size(119, 18);
            this.lbl_y11.TabIndex = 131;
            this.lbl_y11.Text = "Y11  上料Z轴气缸下";
            // 
            // lbl_y10
            // 
            this.lbl_y10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y10.AutoSize = true;
            this.lbl_y10.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y10.ForeColor = System.Drawing.Color.Black;
            this.lbl_y10.Location = new System.Drawing.Point(203, 33);
            this.lbl_y10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y10.Name = "lbl_y10";
            this.lbl_y10.Size = new System.Drawing.Size(119, 18);
            this.lbl_y10.TabIndex = 130;
            this.lbl_y10.Text = "Y10  上料Z轴气缸上";
            // 
            // lbl_y0
            // 
            this.lbl_y0.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_y0.AutoSize = true;
            this.lbl_y0.BackColor = System.Drawing.Color.Transparent;
            this.lbl_y0.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbl_y0.ForeColor = System.Drawing.Color.Black;
            this.lbl_y0.Location = new System.Drawing.Point(38, 33);
            this.lbl_y0.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_y0.Name = "lbl_y0";
            this.lbl_y0.Size = new System.Drawing.Size(68, 18);
            this.lbl_y0.TabIndex = 129;
            this.lbl_y0.Text = "Y0  X_PLU";
            // 
            // tabItem2
            // 
            this.tabItem2.AttachedControl = this.tabControlPanel2;
            this.tabItem2.Name = "tabItem2";
            this.tabItem2.Text = "IO信息(Y)";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "point_green.ico");
            this.imageList1.Images.SetKeyName(1, "point_cyan.ico");
            // 
            // FrmPLCIOInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(817, 645);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmPLCIOInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "IO信号";
            this.TopMost = true;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmPLCIOInfo_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.tabControl1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabControlPanel1.ResumeLayout(false);
            this.tabControlPanel1.PerformLayout();
            this.tabControlPanel2.ResumeLayout(false);
            this.tabControlPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.TabControl tabControl1;
        private DevComponents.DotNetBar.TabControlPanel tabControlPanel1;
        private DevComponents.DotNetBar.LabelX lbl_x77;
        private DevComponents.DotNetBar.LabelX lbl_x76;
        private DevComponents.DotNetBar.LabelX lbl_x75;
        private DevComponents.DotNetBar.LabelX lbl_x74;
        private DevComponents.DotNetBar.LabelX lbl_x73;
        private DevComponents.DotNetBar.LabelX lbl_x72;
        private DevComponents.DotNetBar.LabelX lbl_x71;
        private DevComponents.DotNetBar.LabelX lbl_x70;
        private DevComponents.DotNetBar.LabelX lbl_x67;
        private DevComponents.DotNetBar.LabelX lbl_x66;
        private DevComponents.DotNetBar.LabelX lbl_x65;
        private DevComponents.DotNetBar.LabelX lbl_x64;
        private DevComponents.DotNetBar.LabelX lbl_x63;
        private DevComponents.DotNetBar.LabelX lbl_x62;
        private DevComponents.DotNetBar.LabelX lbl_x61;
        private DevComponents.DotNetBar.LabelX lbl_x60;
        private DevComponents.DotNetBar.LabelX lbl_x57;
        private DevComponents.DotNetBar.LabelX lbl_x56;
        private DevComponents.DotNetBar.LabelX lbl_x55;
        private DevComponents.DotNetBar.LabelX lbl_x54;
        private DevComponents.DotNetBar.LabelX lbl_x53;
        private DevComponents.DotNetBar.LabelX lbl_x52;
        private DevComponents.DotNetBar.LabelX lbl_x51;
        private DevComponents.DotNetBar.LabelX lbl_x50;
        private DevComponents.DotNetBar.LabelX lbl_x47;
        private DevComponents.DotNetBar.LabelX lbl_x46;
        private DevComponents.DotNetBar.LabelX lbl_x45;
        private DevComponents.DotNetBar.LabelX lbl_x44;
        private DevComponents.DotNetBar.LabelX lbl_x43;
        private DevComponents.DotNetBar.LabelX lbl_x42;
        private DevComponents.DotNetBar.LabelX lbl_x41;
        private DevComponents.DotNetBar.LabelX lbl_x40;
        private DevComponents.DotNetBar.LabelX lbl_x37;
        private DevComponents.DotNetBar.LabelX lbl_x36;
        private DevComponents.DotNetBar.LabelX lbl_x35;
        private DevComponents.DotNetBar.LabelX lbl_x34;
        private DevComponents.DotNetBar.LabelX lbl_x33;
        private DevComponents.DotNetBar.LabelX lbl_x32;
        private DevComponents.DotNetBar.LabelX lbl_x31;
        private DevComponents.DotNetBar.LabelX lbl_x27;
        private DevComponents.DotNetBar.LabelX lbl_x25;
        private DevComponents.DotNetBar.LabelX lbl_x30;
        private DevComponents.DotNetBar.LabelX lbl_x26;
        private DevComponents.DotNetBar.LabelX lbl_x24;
        private DevComponents.DotNetBar.LabelX lbl_x23;
        private DevComponents.DotNetBar.LabelX lbl_x22;
        private DevComponents.DotNetBar.LabelX lbl_x21;
        private DevComponents.DotNetBar.LabelX lbl_x20;
        private DevComponents.DotNetBar.LabelX lbl_x17;
        private DevComponents.DotNetBar.LabelX lbl_x16;
        private DevComponents.DotNetBar.LabelX lbl_x15;
        private DevComponents.DotNetBar.LabelX lbl_x14;
        private DevComponents.DotNetBar.LabelX lbl_x13;
        private DevComponents.DotNetBar.LabelX lbl_x12;
        private DevComponents.DotNetBar.LabelX lbl_x7;
        private DevComponents.DotNetBar.LabelX lbl_x6;
        private DevComponents.DotNetBar.LabelX lbl_x5;
        private DevComponents.DotNetBar.LabelX lbl_x4;
        private DevComponents.DotNetBar.LabelX lbl_x3;
        private DevComponents.DotNetBar.LabelX lbl_x2;
        private DevComponents.DotNetBar.LabelX lbl_x1;
        private DevComponents.DotNetBar.LabelX lbl_x11;
        private DevComponents.DotNetBar.LabelX lbl_x10;
        private DevComponents.DotNetBar.LabelX lbl_x0;
        private DevComponents.DotNetBar.TabItem tabItem1;
        private System.Windows.Forms.ImageList imageList1;
        private DevComponents.DotNetBar.TabControlPanel tabControlPanel2;
        private DevComponents.DotNetBar.TabItem tabItem2;
        private DevComponents.DotNetBar.LabelX lbl_y47;
        private DevComponents.DotNetBar.LabelX lbl_y46;
        private DevComponents.DotNetBar.LabelX lbl_y45;
        private DevComponents.DotNetBar.LabelX lbl_y44;
        private DevComponents.DotNetBar.LabelX lbl_y43;
        private DevComponents.DotNetBar.LabelX lbl_y42;
        private DevComponents.DotNetBar.LabelX lbl_y41;
        private DevComponents.DotNetBar.LabelX lbl_y40;
        private DevComponents.DotNetBar.LabelX lbl_y37;
        private DevComponents.DotNetBar.LabelX lbl_y36;
        private DevComponents.DotNetBar.LabelX lbl_y35;
        private DevComponents.DotNetBar.LabelX lbl_y34;
        private DevComponents.DotNetBar.LabelX lbl_y33;
        private DevComponents.DotNetBar.LabelX lbl_y32;
        private DevComponents.DotNetBar.LabelX lbl_y31;
        private DevComponents.DotNetBar.LabelX lbl_y27;
        private DevComponents.DotNetBar.LabelX lbl_y25;
        private DevComponents.DotNetBar.LabelX lbl_y30;
        private DevComponents.DotNetBar.LabelX lbl_y26;
        private DevComponents.DotNetBar.LabelX lbl_y24;
        private DevComponents.DotNetBar.LabelX lbl_y23;
        private DevComponents.DotNetBar.LabelX lbl_y22;
        private DevComponents.DotNetBar.LabelX lbl_y21;
        private DevComponents.DotNetBar.LabelX lbl_y20;
        private DevComponents.DotNetBar.LabelX lbl_y17;
        private DevComponents.DotNetBar.LabelX lbl_y16;
        private DevComponents.DotNetBar.LabelX lbl_y15;
        private DevComponents.DotNetBar.LabelX lbl_y14;
        private DevComponents.DotNetBar.LabelX lbl_y13;
        private DevComponents.DotNetBar.LabelX lbl_y12;
        private DevComponents.DotNetBar.LabelX lbl_y7;
        private DevComponents.DotNetBar.LabelX lbl_y6;
        private DevComponents.DotNetBar.LabelX lbl_y5;
        private DevComponents.DotNetBar.LabelX lbl_y4;
        private DevComponents.DotNetBar.LabelX lbl_y3;
        private DevComponents.DotNetBar.LabelX lbl_y2;
        private DevComponents.DotNetBar.LabelX lbl_y1;
        private DevComponents.DotNetBar.LabelX lbl_y11;
        private DevComponents.DotNetBar.LabelX lbl_y10;
        private DevComponents.DotNetBar.LabelX lbl_y0;
        private ClsDeviceComm.Controls.UserLantern uLan_x7;
        private ClsDeviceComm.Controls.UserLantern uLan_x2;
        private ClsDeviceComm.Controls.UserLantern uLan_x3;
        private ClsDeviceComm.Controls.UserLantern uLan_x5;
        private ClsDeviceComm.Controls.UserLantern uLan_x6;
        private ClsDeviceComm.Controls.UserLantern uLan_x4;
        private ClsDeviceComm.Controls.UserLantern uLan_x1;
        private ClsDeviceComm.Controls.UserLantern uLan_x0;
        private ClsDeviceComm.Controls.UserLantern uLan_x12;
        private ClsDeviceComm.Controls.UserLantern uLan_x13;
        private ClsDeviceComm.Controls.UserLantern uLan_x15;
        private ClsDeviceComm.Controls.UserLantern uLan_x16;
        private ClsDeviceComm.Controls.UserLantern uLan_x14;
        private ClsDeviceComm.Controls.UserLantern uLan_x11;
        private ClsDeviceComm.Controls.UserLantern uLan_x10;
        private ClsDeviceComm.Controls.UserLantern uLan_x17;
        private ClsDeviceComm.Controls.UserLantern uLan_x32;
        private ClsDeviceComm.Controls.UserLantern uLan_x33;
        private ClsDeviceComm.Controls.UserLantern uLan_x35;
        private ClsDeviceComm.Controls.UserLantern uLan_x36;
        private ClsDeviceComm.Controls.UserLantern uLan_x34;
        private ClsDeviceComm.Controls.UserLantern uLan_x31;
        private ClsDeviceComm.Controls.UserLantern uLan_x30;
        private ClsDeviceComm.Controls.UserLantern uLan_x37;
        private ClsDeviceComm.Controls.UserLantern uLan_x22;
        private ClsDeviceComm.Controls.UserLantern uLan_x23;
        private ClsDeviceComm.Controls.UserLantern uLan_x25;
        private ClsDeviceComm.Controls.UserLantern uLan_x26;
        private ClsDeviceComm.Controls.UserLantern uLan_x24;
        private ClsDeviceComm.Controls.UserLantern uLan_x21;
        private ClsDeviceComm.Controls.UserLantern uLan_x20;
        private ClsDeviceComm.Controls.UserLantern uLan_x27;
        private ClsDeviceComm.Controls.UserLantern uLan_x42;
        private ClsDeviceComm.Controls.UserLantern uLan_x43;
        private ClsDeviceComm.Controls.UserLantern uLan_x45;
        private ClsDeviceComm.Controls.UserLantern uLan_x46;
        private ClsDeviceComm.Controls.UserLantern uLan_x44;
        private ClsDeviceComm.Controls.UserLantern uLan_x41;
        private ClsDeviceComm.Controls.UserLantern uLan_x40;
        private ClsDeviceComm.Controls.UserLantern uLan_x47;
        private ClsDeviceComm.Controls.UserLantern uLan_x52;
        private ClsDeviceComm.Controls.UserLantern uLan_x53;
        private ClsDeviceComm.Controls.UserLantern uLan_x55;
        private ClsDeviceComm.Controls.UserLantern uLan_x56;
        private ClsDeviceComm.Controls.UserLantern uLan_x54;
        private ClsDeviceComm.Controls.UserLantern uLan_x51;
        private ClsDeviceComm.Controls.UserLantern uLan_x50;
        private ClsDeviceComm.Controls.UserLantern uLan_x57;
        private ClsDeviceComm.Controls.UserLantern uLan_x72;
        private ClsDeviceComm.Controls.UserLantern uLan_x73;
        private ClsDeviceComm.Controls.UserLantern uLan_x75;
        private ClsDeviceComm.Controls.UserLantern uLan_x76;
        private ClsDeviceComm.Controls.UserLantern uLan_x74;
        private ClsDeviceComm.Controls.UserLantern uLan_x71;
        private ClsDeviceComm.Controls.UserLantern uLan_x70;
        private ClsDeviceComm.Controls.UserLantern uLan_x77;
        private ClsDeviceComm.Controls.UserLantern uLan_x62;
        private ClsDeviceComm.Controls.UserLantern uLan_x63;
        private ClsDeviceComm.Controls.UserLantern uLan_x65;
        private ClsDeviceComm.Controls.UserLantern uLan_x66;
        private ClsDeviceComm.Controls.UserLantern uLan_x64;
        private ClsDeviceComm.Controls.UserLantern uLan_x61;
        private ClsDeviceComm.Controls.UserLantern uLan_x60;
        private ClsDeviceComm.Controls.UserLantern uLan_x67;
        private ClsDeviceComm.Controls.UserLantern uLan_y12;
        private ClsDeviceComm.Controls.UserLantern uLan_y13;
        private ClsDeviceComm.Controls.UserLantern uLan_y15;
        private ClsDeviceComm.Controls.UserLantern uLan_y16;
        private ClsDeviceComm.Controls.UserLantern uLan_y14;
        private ClsDeviceComm.Controls.UserLantern uLan_y11;
        private ClsDeviceComm.Controls.UserLantern uLan_y10;
        private ClsDeviceComm.Controls.UserLantern uLan_y17;
        private ClsDeviceComm.Controls.UserLantern uLan_y2;
        private ClsDeviceComm.Controls.UserLantern uLan_y3;
        private ClsDeviceComm.Controls.UserLantern uLan_y5;
        private ClsDeviceComm.Controls.UserLantern uLan_y6;
        private ClsDeviceComm.Controls.UserLantern uLan_y4;
        private ClsDeviceComm.Controls.UserLantern uLan_y1;
        private ClsDeviceComm.Controls.UserLantern uLan_y0;
        private ClsDeviceComm.Controls.UserLantern uLan_y7;
        private ClsDeviceComm.Controls.UserLantern uLan_y32;
        private ClsDeviceComm.Controls.UserLantern uLan_y33;
        private ClsDeviceComm.Controls.UserLantern uLan_y35;
        private ClsDeviceComm.Controls.UserLantern uLan_y36;
        private ClsDeviceComm.Controls.UserLantern uLan_y34;
        private ClsDeviceComm.Controls.UserLantern uLan_y31;
        private ClsDeviceComm.Controls.UserLantern uLan_y30;
        private ClsDeviceComm.Controls.UserLantern uLan_y37;
        private ClsDeviceComm.Controls.UserLantern uLan_y22;
        private ClsDeviceComm.Controls.UserLantern uLan_y23;
        private ClsDeviceComm.Controls.UserLantern uLan_y25;
        private ClsDeviceComm.Controls.UserLantern uLan_y26;
        private ClsDeviceComm.Controls.UserLantern uLan_y24;
        private ClsDeviceComm.Controls.UserLantern uLan_y21;
        private ClsDeviceComm.Controls.UserLantern uLan_y20;
        private ClsDeviceComm.Controls.UserLantern uLan_y27;
        private ClsDeviceComm.Controls.UserLantern uLan_y42;
        private ClsDeviceComm.Controls.UserLantern uLan_y43;
        private ClsDeviceComm.Controls.UserLantern uLan_y45;
        private ClsDeviceComm.Controls.UserLantern uLan_y44;
        private ClsDeviceComm.Controls.UserLantern uLan_y41;
        private ClsDeviceComm.Controls.UserLantern uLan_y40;
        private ClsDeviceComm.Controls.UserLantern uLan_y47;
        private ClsDeviceComm.Controls.UserLantern uLan_y46;
        private ClsDeviceComm.Controls.UserLantern userLantern100;
    }
}