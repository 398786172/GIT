﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCV
{
    public class ClsPLCValue
    {
        public static bool connectSuccess = false;
        public static ClsPLCModel PlcValue = new ClsPLCModel();  //PLC设备状态
    }
}
