﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCV.MESHelper
{
   public class OCVResultUpLoadData2
    {
        /// <summary>
        /// 参数编码
        /// </summary>
        public string parameter_code { set; get; }
        /// <summary>
        /// 参数名称
        /// </summary>
        public string parameter_name { set; get; }
        /// <summary>
        /// 参数实际值
        /// </summary>
        public string parameter_value { set; get; }
    }
}
