﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCS.Common
{
   public class DictionaryEx:Dictionary<string,string>
    {
    }
}
