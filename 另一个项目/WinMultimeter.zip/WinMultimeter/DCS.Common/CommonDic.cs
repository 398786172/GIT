﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCS.Common
{
   public class CommonDic
    {
        public static Dictionary<string, object> DicVariable = new Dictionary<string, object>();
    }
}
